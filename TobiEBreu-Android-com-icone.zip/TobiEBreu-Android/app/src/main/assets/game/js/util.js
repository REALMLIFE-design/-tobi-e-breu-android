/* util.js — utilidades, carregador de imagens, variantes de cor (sem getImageData: funciona em file://) */
const G = window.G = { VERSION: '1.0', W: 1280, H: 720, img: {}, cache: {}, flags: {}, S: null };
G.clamp = (v, a, b) => v < a ? a : v > b ? b : v;
G.lerp = (a, b, t) => a + (b - a) * t;
G.rnd = (a = 1, b) => b === undefined ? Math.random() * a : a + Math.random() * (b - a);
G.irnd = (a, b) => Math.floor(G.rnd(a, b + 1));
G.pick = a => a[Math.floor(Math.random() * a.length)];
G.dist = (a, b) => Math.hypot(a.x - b.x, (a.y - b.y) * 2);
G.seeded = function (seed) { let s = seed >>> 0 || 1; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; };
G.hashStr = s => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; };

const SPRITES = ['gnome_idle','gnome_walk1','gnome_walk2','gnome_cheer','gnome_talk','gnome_arm','gnome_sword','cat1','cat2','cat3','cat_gray',
  'rat1','rat2','gob_olive','gob_olive2','gob_green','gob_green2','bird','knight','knight2','warlock','ogre','wiz_face','oldgreen','wizard','wizard2'];
const BGS = ['forest_meadow','castle_ridge','gold_cave','village','giant_tree','tree_door','grassland','rock_door','cave_glow','rock_cave','lake_sunset',
  'summit_sky','misty_lake','autumn','coast','tangle','canyon_arch','canyon_red','aerial','swamp','river','marsh','rays_cave','river2','dark_forest',
  'snow_cave','skull_cave','bedroom','tavern','hall','cozy','forest_swamp','dark_bridge','ruins_dark','beanstalk','night_forest','cave_castle','bg_roots'];

const TEXS = ['cabin', 'anvil', 'archway', 'barrel', 'barrels', 'bridge', 'bush1', 'bush_mt', 'chair', 'chest_c', 'chest_o', 'column', 'conifer1', 'conifer2', 'crate', 'crate_g', 'crate_g2', 'crate_g3', 'crates', 'cross', 'dead1', 'dead2', 'dead3', 'dead4', 'door_stone_c', 'door_stone_o', 'door_wood_c', 'door_wood_o', 'fence', 'fence2', 'fern', 'fir1', 'fir2', 'fire1', 'fire2', 'flowers', 'golem', 'grass', 'hay', 'logs', 'mine', 'oak1', 'oak2', 'oak3', 'pile', 'pine1', 'pine2', 'reeds', 'rock1', 'rock2', 'rock3', 'rock4', 'rock5', 'rockg', 'rockp1', 'rockp2', 'ruin', 'sack', 'shrub', 'signpost', 'stairs', 'stump', 'table', 'tent', 'tombstone', 'tree_b', 'tree_d1', 'tree_d2', 'tree_g1', 'tree_round', 'tree_small', 'tuft', 'wall_stone', 'wall_window', 'wall_wood', 'well'];
const ICONS = ['armor', 'axe', 'backpack', 'bow', 'coin', 'dagger', 'envelope', 'gemBlue', 'gemGreen', 'gemRed', 'hammer', 'heart', 'helmet', 'map', 'potionBlue', 'potionGreen', 'potionRed', 'scroll', 'shield', 'shieldSmall', 'sword', 'swordWood', 'tome', 'tools', 'upg_armor', 'upg_axe', 'upg_bow', 'upg_dagger', 'upg_hammer', 'upg_helmet', 'upg_shield', 'upg_spear', 'upg_sword', 'upg_wand', 'wand', 'x'];
const UIS = ['button_bean', 'button_circle', 'button_circle_wide', 'button_hexagon', 'button_square', 'icon_arrow', 'icon_arrow_curved', 'icon_arrow_rotate', 'icon_burst', 'icon_button_a', 'icon_button_b', 'icon_button_x', 'icon_button_y', 'icon_cog', 'icon_crosshair', 'icon_fire', 'icon_hand', 'icon_jump', 'icon_key', 'icon_menu', 'icon_money', 'icon_music', 'icon_pause', 'icon_save', 'icon_shield', 'icon_skull', 'icon_sound', 'icon_star', 'icon_sword', 'icon_talk', 'icon_target', 'icon_wrench', 'joystick_circle_nub_a', 'joystick_circle_nub_b', 'joystick_circle_pad_a', 'joystick_circle_pad_b'];
const CATS = ['idle','walk0','walk1','walk2','walk3','walk4','walk5','run0','run1','run2','run3','run4','run5'];
G.loadAll = function (onProgress) {
  const list = SPRITES.map(n => ['s', n, 'assets/sprites/' + n + '.png']).concat(BGS.map(n => ['b', n, 'assets/bg/' + n + '.jpg']), TEXS.map(n => ['t', n, 'assets/tex/' + n + '.png']), ICONS.map(n => ['i', n, 'assets/icons/' + n + '.png']), UIS.map(n => ['u', n, 'assets/ui/' + n + '.png']), CATS.map(n => ['c', n, 'assets/cat/' + n + '.png']));
  let done = 0;
  return Promise.all(list.map(([t, n, src]) => new Promise(res => {
    const im = new Image();
    im.onload = im.onerror = () => { done++; onProgress && onProgress(done / list.length); res(); };
    im.src = src; G.img[({ s: '', b: 'bg_', t: 't_', i: 'i_', u: 'u_', c: 'c_' })[t] + n] = im;
  })));
};

/* Variante colorida via mistura 'hue'/'color' (preserva contornos pretos e alfa). */
G.variant = function (key, o = {}) {
  const id = key + JSON.stringify(o);
  if (G.cache[id]) return G.cache[id];
  const im = G.img[key]; if (!im || !im.width) return im;
  const c = document.createElement('canvas'); c.width = im.width; c.height = im.height;
  const x = c.getContext('2d');
  x.drawImage(im, 0, 0);
  if (o.hue) { x.globalCompositeOperation = 'hue'; x.fillStyle = o.hue; x.fillRect(0, 0, c.width, c.height); }
  if (o.sat) { x.globalCompositeOperation = 'saturation'; x.fillStyle = o.sat; x.fillRect(0, 0, c.width, c.height); }
  if (o.mul) { x.globalCompositeOperation = 'multiply'; x.fillStyle = o.mul; x.fillRect(0, 0, c.width, c.height); }
  if (o.add) { x.globalCompositeOperation = 'lighter'; x.fillStyle = o.add; x.fillRect(0, 0, c.width, c.height); }
  x.globalCompositeOperation = 'destination-in'; x.drawImage(im, 0, 0);
  G.cache[id] = c; return c;
};
/* Silhueta branca (flash de dano) */
G.white = function (src) {
  const id = 'w' + (src.src || src._id || (src._id = Math.random()));
  if (G.cache[id]) return G.cache[id];
  const c = document.createElement('canvas'); c.width = src.width; c.height = src.height;
  const x = c.getContext('2d'); x.drawImage(src, 0, 0); x.globalCompositeOperation = 'source-in'; x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height);
  G.cache[id] = c; return c;
};
G.save = function () { try { return JSON.parse(localStorage.getItem('gnomo_save_v1')); } catch (e) { return null; } };
G.settings = (() => { let s = { music: .6, sfx: .8, lang: 'pt', shadows: true, particles: true, light: true, touch: 'auto', hudO: 1, touO: .85, touS: 1, catPix: true, jx: 0, jy: 0, bx: 0, by: 0 };
  try { Object.assign(s, JSON.parse(localStorage.getItem('gnomo_settings'))); } catch (e) {}
  return s; })();
G.saveSettings = () => { try { localStorage.setItem('gnomo_settings', JSON.stringify(G.settings)); } catch (e) {} };

/* ícones de itens (pacote Ravenmore) */
G.ICON = { potion_hp: 'potionRed', potion_hp2: 'potionRed', potion_en: 'potionBlue', elixir: 'potionGreen', sword_wood: 'swordWood', sword_iron: 'sword', sword_steel: 'upg_sword', sword_elf: 'upg_sword', sword_ruby: 'upg_dagger', sword_master: 'upg_sword',
  tunic: 'armor', leather: 'armor', chain: 'upg_armor', silver: 'upg_armor', arcane: 'upg_helmet', am_vigor: 'heart', am_cat: 'gemGreen', am_ruby: 'gemRed', am_wind: 'upg_wand', am_mage: 'gemBlue',
  gem: 'gemBlue', rune: 'scroll', letter: 'envelope', frag: 'gemRed', heart: 'heart', key_iron: 'tools', iron: 'hammer', apple: null, stew: null };
G.itemSrc = id => { const n = G.ICON[id]; return n ? 'assets/icons/' + n + '.png' : ({ mushroom: 'assets/tex/flowers.png', flower: 'assets/tex/flowers.png', herb: 'assets/tex/fern.png', plank: 'assets/tex/logs.png' })[id] || null; };
G.itemImg = id => { const n = G.ICON[id]; if (n) return G.img['i_' + n]; return ({ mushroom: G.img.t_flowers, flower: G.img.t_flowers, herb: G.img.t_fern, plank: G.img.t_logs })[id] || null; };
G.ico = id => { const s = G.itemSrc(id); return s ? '<img class="ico" src="' + s + '">' : (G.ITEMS[id] ? G.ITEMS[id].ic : ''); };
G.COIN = '<img class="ci" src="assets/icons/coin.png">';
G.SKICON = { spin: 'assets/ui/icon_arrow_rotate.png', fire: 'assets/ui/icon_fire.png', heal: 'assets/icons/heart.png', thunder: 'assets/ui/icon_burst.png', claw: 'assets/ui/icon_crosshair.png' };

G.applyHud = function () { const s = G.settings, r = document.documentElement.style;
  r.setProperty('--hudo', s.hudO); r.setProperty('--touo', s.touO); r.setProperty('--tous', s.touS);
  r.setProperty('--jx', s.jx + 'px'); r.setProperty('--jy', s.jy + 'px'); r.setProperty('--bx', s.bx + 'px'); r.setProperty('--by', s.by + 'px'); };
