/* props.js — cenário montado SOMENTE com as texturas enviadas (assets/tex). Nada é desenhado por código aqui. */
const P2 = G.props = {};
const TEX = n => G.img['t_' + n];
/* altura-alvo (px no mundo, escala 1) de cada textura */
const HT = { oak1: 230, oak2: 220, oak3: 230, tree_round: 230, tree_b: 190, pine1: 260, pine2: 250, fir1: 270, fir2: 260, conifer1: 150, conifer2: 130, dead1: 210, dead2: 280, dead3: 280, dead4: 250,
  bush1: 80, bush_mt: 120, shrub: 50, fern: 50, tuft: 56, grass: 90, reeds: 70, flowers: 50, rock1: 90, rock2: 80, rock3: 80, rock4: 50, rockg: 40, rockp1: 190, rockp2: 200, column: 200,
  barrel: 74, barrels: 90, crate: 70, crates: 90, crate_g: 56, fence: 90, fence2: 60, golem: 130, cross: 80, tombstone: 60, stump: 44, hay: 62, logs: 50, sack: 50, table: 90, chair: 74, anvil: 56, chest_c: 50, chest_o: 64, fire2: 56, fire1: 90, tent: 100, signpost: 100, well: 70 };
const KIND = {
  tree: ['oak1', 'oak2', 'oak3', 'tree_round', 'tree_b'], pine: ['pine1', 'pine2', 'fir1', 'fir2', 'conifer1', 'conifer2'], dead: ['dead1', 'dead2', 'dead3', 'dead4'],
  bush: ['bush1', 'bush_mt', 'shrub', 'fern', 'tuft'], rock: ['rock1', 'rock2', 'rock3', 'rock4', 'rockg'], stalag: ['rockp1', 'rockp2'], column: ['column'], reed: ['reeds', 'grass'],
  barrel: ['barrel', 'barrels'], crate: ['crate', 'crates', 'crate_g'], fence: ['fence', 'fence2'], statue: ['golem', 'cross', 'tombstone'], mush: ['flowers', 'stump'], flowers: ['flowers'] };
P2.grade = (name, im) => { const bk = P2.bgKey || '', id = 'g_' + name + bk; if (G.cache[id]) return G.cache[id]; const bg = G.img['bg_' + bk];
  const k = document.createElement('canvas'); k.width = im.width; k.height = im.height; const x = k.getContext('2d');
  try { x.filter = 'saturate(.62) contrast(.92) brightness(.95)'; } catch (e) {} x.drawImage(im, 0, 0); x.filter = 'none';
  if (bg && bg.width) { x.globalCompositeOperation = 'source-atop'; x.globalAlpha = .42; x.drawImage(bg, 0, bg.height * .45, bg.width, bg.height * .55, 0, 0, k.width, k.height); x.globalAlpha = .12; x.fillStyle = '#1b2a14'; x.fillRect(0, 0, k.width, k.height); }
  G.cache[id] = k; return k; };
P2.drawTex = (c, name, x, y, h, flip, alpha) => { let im = TEX(name); if (im && im.width && !/^(fire|chest)/.test(name)) im = P2.grade(name, im); if (!im || !im.width) return; const w = h * im.width / im.height; c.save(); if (alpha !== undefined) c.globalAlpha = alpha; c.translate(x, y); if (flip) c.scale(-1, 1); c.drawImage(im, -w / 2, -h, w, h); c.restore(); };
P2.pickTex = (k, v, bi) => { let list = KIND[k] || KIND.rock; if (k === 'tree' && bi === 'snow') list = KIND.pine; if ((k === 'tree' || k === 'bush') && bi === 'swamp') list = k === 'tree' ? KIND.dead : KIND.reed; if (k === 'column' && bi === 'cave') list = KIND.stalag; return list[v % list.length]; };
P2.BIOME = {
  forest:[['tree',5,26,13],['bush',3,34,12],['rock',2,34,14],['mush',1,14,8]], village:[['bush',3,34,12],['barrel',2,22,10],['fence',2,36,8],['crate',1,26,10]],
  swamp:[['dead',4,16,10],['reed',4,30,10],['rock',2,34,14]], water:[['tree',3,26,13],['rock',3,34,14],['reed',3,30,10],['bush',2,34,12]],
  cave:[['stalag',5,28,12],['rock',4,34,14]], snow:[['pine',5,22,12],['rock',3,34,14]], canyon:[['rock',6,38,16],['stalag',2,28,12]],
  ruins:[['column',4,26,12],['rock',3,34,14],['statue',1,26,12]], field:[['bush',4,34,12],['rock',3,34,14],['tree',2,26,13]],
  castle:[['column',3,26,12],['barrel',3,22,10],['crate',3,26,10],['statue',1,26,12]], dungeon:[['column',3,26,12],['barrel',3,22,10],['crate',2,26,10],['rock',2,34,14]],
  temple:[['column',5,26,12],['statue',2,26,12]], summit:[['rock',3,34,14]],
};
P2.drawProp = (c, o, t, bi) => { const n = P2.pickTex(o.k, o.v, bi), h = (HT[n] || 80) * (o.s || 1); P2.drawTex(c, n, o.x, o.y, h, o.v % 2 === 1); };
P2.campfire = (c, x, y, t) => { const fl = 1 + Math.sin(t * 13 + x) * .05; P2.drawTex(c, 'fire2', x, y + 4, HT.fire2); P2.drawTex(c, 'fire1', x, y - 4, HT.fire1 * fl); };
/* casa: parede com janela + parede com porta + parede com janela (escalonadas em diagonal, como no pacote isométrico) */
P2.house = (c, h, t, open) => {
  const stone = h.int === 'hall', D = stone ? 'door_stone' : 'door_wood', k = 1.0;
  c.fillStyle = 'rgba(0,0,0,.28)'; c.beginPath(); c.ellipse(h.x, h.y + 6, 90, 12, 0, 0, Math.PI * 2); c.fill();
  if (h.tree) P2.drawTex(c, 'oak1', h.x, h.y + 10, 330);
  const cb = TEX('cabin'); if (cb && cb.width) { const g = P2.grade('cabin', cb), hh = 230, ww = hh * cb.width / cb.height; c.drawImage(g, h.x - .42 * ww, h.y + .08 * hh - hh, ww, hh);
    const dw = .13 * ww, dh = .36 * hh, dx = h.x - dw / 2, dy = h.y - dh + 6; if (open > .5) { c.fillStyle = 'rgba(12,8,4,.88)'; c.fillRect(dx, dy, dw, dh); c.fillStyle = 'rgba(255,200,110,.22)'; c.fillRect(dx, dy, dw, dh); } }
  else { const im = TEX(D + (open > .5 ? '_o' : '_c')), ic = TEX(D + '_c'); if (im && ic) { const w = im.width * k, hh = im.height * k, wc = ic.width * k; c.drawImage(im, h.x + wc / 2 - w, h.y - hh, w, hh); } }
  if (h.name) { c.font = 'bold 13px Trebuchet MS'; c.textAlign = 'center'; const tw = c.measureText(h.name).width + 16; c.fillStyle = 'rgba(20,12,4,.78)'; c.fillRect(h.x - tw / 2, h.y + 14, tw, 20); c.fillStyle = '#ffe9b0'; c.fillText(h.name, h.x, h.y + 29); }
};
P2.bridge = (c, wx, ww, cy, hw, fixed) => { const n = fixed ? Math.ceil(ww / 120) + 1 : 1; for (let i = 0; i < n; i++) { const x = fixed ? wx + 20 + i * (ww - 40) / Math.max(1, n - 1) : (i ? wx + ww : wx); P2.drawTex(c, 'bridge', x, cy + 26, 100); } };
P2.chest = (c, x, y, open, t, glow) => { c.fillStyle = 'rgba(0,0,0,.3)'; c.beginPath(); c.ellipse(x, y, 30, 9, 0, 0, Math.PI * 2); c.fill(); P2.drawTex(c, open ? 'chest_o' : 'chest_c', x, y + 4, open ? HT.chest_o : HT.chest_c); };
/* mobília de interior (somente o que tem textura) */
P2.furn = (c, k, x, y, t) => { if (k === 'fire') return P2.campfire(c, x, y, t); if (k === 'chest') return P2.drawTex(c, 'chest_c', x, y + 4, HT.chest_c); P2.drawTex(c, k, x, y + 4, HT[k] || 70); };
P2.FW = { table: [50, 12], chair: [20, 8], barrel: [24, 10], barrels: [50, 12], crate: [30, 10], crates: [40, 12], anvil: [30, 10], sack: [16, 8], hay: [50, 12], logs: [40, 10], fire: [26, 10], column: [28, 10], chest: [30, 10] };

/* ================== CONSTRUÇÃO DE ÁREAS ================== */
P2.build = function (def, S) {
  const r = G.seeded(G.hashStr(def.id)), W = def.W, gy = def.gy || [430, 690];
  const w = { def, W, gy, obs: [], deco: [], fg: [], houses: [], torches: [], camps: [], water: null, pal: def.bi === 'forest' && def.bg === 'autumn' ? 'autumn' : def.music === 'night' ? 'night' : def.bi === 'swamp' ? 'swamp' : 'forest', n: 0 };
  // trilha sinuosa
  const step = 40, N = Math.ceil(W / step) + 2; w.cy = []; w.hw = [];
  let cy = 565, ph = r() * 6;
  for (let i = 0; i < N; i++) { ph += .18 + r() * .1; w.cy.push(G.clamp(565 + Math.sin(ph) * 46 + Math.sin(ph * .43) * 20, 505, 615)); w.hw.push(G.clamp(70 + Math.sin(ph * 1.7) * 14, 58, 92)); }
  // regiões planas (casas/NPC/água) — achata trilha
  const flat = (x0, x1, y, hwv) => { for (let i = 0; i < N; i++) { const x = i * step; if (x >= x0 && x <= x1) { const k = G.clamp(Math.min(x - x0, x1 - x) / 100, 0, 1); w.cy[i] = G.lerp(w.cy[i], y, k); w.hw[i] = G.lerp(w.hw[i], hwv, k); } } };
  flat(0, 260, 565, 80); flat(W - 260, W, 565, 80);
  (def.houses || []).forEach(h => flat(h.x - 120, h.x + 120, 575, 76));
  if (def.water) flat(def.water.x - 120, def.water.x + def.water.w + 120, 570, 62);
  w.path = x => { const f = G.clamp(x / step, 0, N - 2), i = Math.floor(f), k = f - i, cy = G.lerp(w.cy[i], w.cy[i + 1], k), hw = G.lerp(w.hw[i], w.hw[i + 1], k); return { yt: cy - hw, yb: cy + hw, cy }; };
  // casas
  (def.houses || []).forEach(h => { const p = w.path(h.x), big = h.int === 'hall' ? 1.25 : 1; const hh = h.tree ? 0 : 150 * big, ww = 190 * big;
    const hb = { x: h.x, y: p.yt - 10, w: ww, hh, col: h.col, roof: ['#b5442a', '#8a3a2a', '#4a6a8a', '#7a5a2a'][G.hashStr(h.name) % 4], name: h.name, int: h.int, open: 0, tree: h.tree, smoke: h.int !== 'hall' && !h.tree };
    w.houses.push(hb); w.obs.push({ x: h.x, y: p.yt - 18, rx: ww / 2 + 6, ry: 18, k: 'house' }); });
  // água + ponte
  if (def.water) { const wt = def.water; w.water = { x: wt.x, w: wt.w, mis: def.bg === 'misty_lake' };
    const p = w.path(wt.x + wt.w / 2); w.bridgeY = p.cy; w.bridgeHW = Math.min(p.yb - p.cy, 52);
    w.obs.push({ x: wt.x + wt.w / 2, y: (gy[0] + p.cy - w.bridgeHW) / 2, rx: wt.w / 2 + 4, ry: (p.cy - w.bridgeHW - gy[0]) / 2, k: 'water' });
    w.obs.push({ x: wt.x + wt.w / 2, y: (720 + p.cy + w.bridgeHW) / 2, rx: wt.w / 2 + 4, ry: (720 - p.cy - w.bridgeHW) / 2, k: 'water' }); }
  // obstáculos dentro da trilha + decoração
  const list = P2.BIOME[def.bi] || P2.BIOME.forest, tot = list.reduce((a, b) => a + b[1], 0);
  const choose = () => { let q = r() * tot; for (const b of list) { q -= b[1]; if (q <= 0) return b; } return list[0]; };
  const skip = x => (def.houses || []).some(h => Math.abs(h.x - x) < 170) || (def.water && x > def.water.x - 140 && x < def.water.x + def.water.w + 140) || x < 280 || x > W - 280 || (def.npcs || []).some(n => Math.abs(n.x - x) < 110) || (def.boss && x > W - 800 && x < W - 300) || (def.camp || []).some(cx => Math.abs(cx - x) < 90);
  for (let x = 360; x < W - 300; x += 190 + r() * 160) {
    if (skip(x)) continue; const b = choose(), p = w.path(x), top = r() < .5, ry = b[3];
    const y = top ? p.yt + ry + 4 : p.yb - ry - 4, s = G.lerp(.8, 1.15, (y - gy[0]) / (gy[1] - gy[0]));
    w.obs.push({ x, y, rx: b[2] * s, ry: ry * s, k: b[0], s, v: Math.floor(r() * 99), draw: true });
  }
  // decoração acima da trilha (camadas de profundidade)
  const dens = def.bi === 'summit' ? 220 : (def.bi === 'cave' || def.bi === 'dungeon') ? 120 : 90;
  for (let x = 20; x < W; x += dens * (.6 + r() * .8)) { const p = w.path(x), room = p.yt - gy[0]; if (room < 40) continue; const yy = gy[0] + 12 + r() * (room - 24), s = G.lerp(.62, 1.0, G.clamp((yy - gy[0]) / room, 0, 1));
    let b = choose(); if (b[0] === 'fence' || b[0] === 'mush') b = list[0]; w.deco.push({ x, y: yy, s, k: b[0], v: Math.floor(r() * 99) }); }
  // plano de frente (somente baixos)
  for (let x = 30; x < W; x += 210 + r() * 240) { const p = w.path(x), yy = Math.min(712, p.yb + 26 + r() * 20); const k = def.bi === 'snow' || def.bi === 'canyon' || def.bi === 'cave' ? 'rock' : def.bi === 'swamp' ? 'reed' : 'bush'; w.fg.push({ x, y: yy, s: 1.15, k, v: Math.floor(r() * 99) }); }
    (def.camp || []).forEach(x => w.camps.push({ x, y: w.path(x).cy + 6 }));
  w.camps.forEach(c => w.obs.push({ x: c.x, y: c.y - 4, rx: 24, ry: 10, k: 'camp' }));
  return w;
};
/* testa se (x,y) é caminhável (raio rx,ry) */
P2.walkable = function (w, x, y, rx = 12, ry = 6) {
  if (x < 14 || x > w.W - 14) return false;
  const p = w.path(x); if (y < p.yt || y > p.yb) return false;
  if (w.water) { const wt = w.water; if (x > wt.x - 4 && x < wt.x + wt.w + 4) { if (Math.abs(y - w.bridgeY) > w.bridgeHW) return false; } }
  for (const o of w.obs) { if (o.k === 'water') continue; if (Math.abs(x - o.x) < o.rx + rx && Math.abs(y - o.y) < o.ry + ry) return false; }
  return true;
};
