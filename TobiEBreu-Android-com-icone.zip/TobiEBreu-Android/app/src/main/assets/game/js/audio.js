/* audio.js — música e efeitos 100% sintetizados (WebAudio). Recursos originais, sem arquivos externos. */
const A = G.audio = {
  ctx: null, master: null, mus: null, sfxg: null, amb: null, cur: null, timer: null, step: 0, next: 0, amb_t: null, ambName: '',
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const C = window.AudioContext || window.webkitAudioContext; if (!C) return;
    const c = this.ctx = new C();
    this.master = c.createGain(); this.master.connect(c.destination);
    this.mus = c.createGain(); this.mus.connect(this.master);
    this.sfxg = c.createGain(); this.sfxg.connect(this.master);
    this.amb = c.createGain(); this.amb.connect(this.master);
    const len = c.sampleRate * 2, b = c.createBuffer(1, len, c.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1; this.noiseBuf = b;
    this.vol(); this.timer = setInterval(() => this.tick(), 60);
  },
  vol() { if (!this.ctx) return; this.mus.gain.value = G.settings.music * .5; this.sfxg.gain.value = G.settings.sfx; this.amb.gain.value = G.settings.sfx * .35; },
  /* ---------- instrumentos ---------- */
  tone(t, f, d, type = 'triangle', v = .2, dest = null, slide = 0) {
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t); if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f + slide), t + d);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + .015); g.gain.exponentialRampToValueAtTime(.0008, t + d);
    o.connect(g); g.connect(dest || this.sfxg); o.start(t); o.stop(t + d + .05);
  },
  noise(t, d, v = .2, f = 2000, q = 1, type = 'bandpass', dest = null, f2 = 0) {
    const c = this.ctx, s = c.createBufferSource(), fl = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf; fl.type = type; fl.frequency.setValueAtTime(f, t); if (f2) fl.frequency.exponentialRampToValueAtTime(f2, t + d); fl.Q.value = q;
    g.gain.setValueAtTime(v, t); g.gain.exponentialRampToValueAtTime(.0008, t + d);
    s.connect(fl); fl.connect(g); g.connect(dest || this.sfxg); s.start(t, Math.random()); s.stop(t + d + .05);
  },
  /* ---------- efeitos ---------- */
  sfx(n) {
    if (!this.ctx || G.settings.sfx <= 0) return; const t = this.ctx.currentTime;
    switch (n) {
      case 'step': this.noise(t, .07, .12, 600 + Math.random() * 300, .8, 'lowpass'); break;
      case 'stepw': this.noise(t, .09, .1, 1200, 3, 'bandpass'); break;
      case 'swing': this.noise(t, .16, .22, 900, 1.2, 'bandpass', null, 3200); break;
      case 'swing2': this.noise(t, .24, .3, 500, 1, 'bandpass', null, 2600); this.tone(t, 160, .2, 'sawtooth', .08, null, -60); break;
      case 'hit': this.noise(t, .12, .35, 1800, .7); this.tone(t, 180, .12, 'square', .15, null, -100); break;
      case 'crit': this.noise(t, .2, .4, 2400, .5); this.tone(t, 320, .22, 'square', .2, null, -200); break;
      case 'hurt': this.tone(t, 300, .25, 'sawtooth', .22, null, -200); this.noise(t, .1, .25, 900); break;
      case 'block': this.tone(t, 900, .1, 'square', .18); this.tone(t + .02, 1300, .12, 'triangle', .14); this.noise(t, .05, .3, 4000); break;
      case 'dodge': this.noise(t, .22, .2, 400, .8, 'bandpass', null, 2000); break;
      case 'jump': this.tone(t, 260, .18, 'triangle', .2, null, 260); break;
      case 'land': this.noise(t, .1, .18, 300, .7, 'lowpass'); break;
      case 'magic': for (let i = 0; i < 5; i++) this.tone(t + i * .04, 500 + i * 180, .25, 'sine', .15); this.noise(t, .4, .1, 3000, 2); break;
      case 'fire': this.noise(t, .45, .3, 800, .6, 'lowpass', null, 3000); this.tone(t, 140, .4, 'sawtooth', .1, null, 200); break;
      case 'heal': [523, 659, 784, 1046].forEach((f, i) => this.tone(t + i * .08, f, .35, 'sine', .18)); break;
      case 'thunder': this.noise(t, .7, .5, 300, .5, 'lowpass', null, 80); this.tone(t, 90, .6, 'sawtooth', .2, null, -50); break;
      case 'spin': this.noise(t, .4, .25, 600, 1, 'bandpass', null, 2400); break;
      case 'meow': this.tone(t, 700, .35, 'triangle', .22, null, 500); this.tone(t + .05, 1400, .3, 'sine', .08, null, -500); break;
      case 'catclaw': this.noise(t, .15, .3, 3500, 2); this.tone(t, 900, .12, 'sawtooth', .1, null, -500); break;
      case 'squeak': this.tone(t, 1700, .1, 'square', .1, null, 700); this.tone(t + .1, 1900, .1, 'square', .08, null, -400); break;
      case 'growl': this.tone(t, 90, .5, 'sawtooth', .25, null, -30); this.noise(t, .5, .1, 300, 2, 'lowpass'); break;
      case 'roar': this.tone(t, 70, 1, 'sawtooth', .35, null, -20); this.noise(t, 1, .25, 400, 1, 'lowpass', null, 120); break;
      case 'caw': this.tone(t, 500, .2, 'sawtooth', .13, null, -200); this.tone(t + .22, 480, .2, 'sawtooth', .13, null, -200); break;
      case 'door': this.tone(t, 110, .5, 'sawtooth', .13, null, 90); this.noise(t, .5, .1, 500, 6, 'bandpass', null, 900); break;
      case 'chest': this.tone(t, 150, .25, 'square', .12, null, 60); [784, 988, 1175, 1568].forEach((f, i) => this.tone(t + .2 + i * .07, f, .3, 'triangle', .15)); break;
      case 'coin': this.tone(t, 1319, .08, 'square', .1); this.tone(t + .07, 1760, .2, 'square', .1); break;
      case 'pick': this.tone(t, 880, .1, 'triangle', .15); this.tone(t + .06, 1175, .15, 'triangle', .13); break;
      case 'ui': this.tone(t, 660, .06, 'square', .08); break;
      case 'ok': this.tone(t, 520, .08, 'square', .1); this.tone(t + .07, 780, .1, 'square', .1); break;
      case 'no': this.tone(t, 200, .18, 'square', .13); break;
      case 'level': [523, 659, 784, 1046, 1318].forEach((f, i) => this.tone(t + i * .09, f, .4, 'triangle', .2)); break;
      case 'quest': [392, 523, 659].forEach((f, i) => this.tone(t + i * .12, f, .35, 'triangle', .17)); break;
      case 'die': this.tone(t, 400, .7, 'sawtooth', .22, null, -350); break;
      case 'slam': this.noise(t, .5, .5, 200, .5, 'lowpass'); this.tone(t, 70, .4, 'sine', .4, null, -30); break;
      case 'warn': this.tone(t, 440, .12, 'square', .08); this.tone(t + .15, 440, .12, 'square', .08); break;
      case 'bossdie': this.noise(t, 1.4, .5, 600, .5, 'lowpass', null, 60); [200, 150, 100, 70].forEach((f, i) => this.tone(t + i * .2, f, .6, 'sawtooth', .2, null, -40)); break;
    }
  },
  /* ---------- música procedural ---------- */
  themes: {
    menu:    { bpm: 84,  root: 57, sc: [0, 2, 3, 5, 7, 8, 10], lead: 'triangle', pad: 'sine', dens: .5, perc: 0, seed: 1 },
    forest:  { bpm: 88,  root: 62, sc: [0, 2, 4, 7, 9], lead: 'triangle', pad: 'sine', dens: .55, perc: 0, seed: 11 },
    village: { bpm: 112, root: 65, sc: [0, 2, 4, 5, 7, 9, 11], lead: 'square', pad: 'triangle', dens: .8, perc: 1, seed: 21 },
    swamp:   { bpm: 70,  root: 55, sc: [0, 1, 3, 5, 7, 8], lead: 'sine', pad: 'sawtooth', dens: .4, perc: 0, seed: 31 },
    water:   { bpm: 76,  root: 60, sc: [0, 2, 4, 7, 9], lead: 'sine', pad: 'triangle', dens: .6, perc: 0, seed: 41 },
    cave:    { bpm: 60,  root: 48, sc: [0, 2, 3, 6, 7], lead: 'sine', pad: 'sawtooth', dens: .3, perc: 0, seed: 51 },
    snow:    { bpm: 72,  root: 69, sc: [0, 2, 4, 7, 9], lead: 'sine', pad: 'triangle', dens: .5, perc: 0, seed: 61, bell: 1 },
    canyon:  { bpm: 96,  root: 52, sc: [0, 1, 4, 5, 7, 8, 11], lead: 'sawtooth', pad: 'triangle', dens: .55, perc: 1, seed: 71 },
    night:   { bpm: 66,  root: 57, sc: [0, 3, 5, 7, 10], lead: 'sine', pad: 'sine', dens: .4, perc: 0, seed: 81 },
    castle:  { bpm: 92,  root: 50, sc: [0, 2, 3, 5, 7, 8, 11], lead: 'sawtooth', pad: 'square', dens: .5, perc: 1, seed: 91 },
    ruins:   { bpm: 68,  root: 53, sc: [0, 2, 3, 5, 7, 10], lead: 'triangle', pad: 'sawtooth', dens: .35, perc: 0, seed: 101 },
    battle:  { bpm: 148, root: 52, sc: [0, 2, 3, 5, 7, 8, 10], lead: 'sawtooth', pad: 'square', dens: .9, perc: 2, seed: 111 },
    boss:    { bpm: 132, root: 46, sc: [0, 1, 3, 5, 6, 8, 11], lead: 'sawtooth', pad: 'sawtooth', dens: .85, perc: 3, seed: 121 },
    final:   { bpm: 150, root: 43, sc: [0, 1, 3, 5, 7, 8, 11], lead: 'sawtooth', pad: 'square', dens: 1, perc: 3, seed: 131 },
    victory: { bpm: 100, root: 60, sc: [0, 2, 4, 5, 7, 9, 11], lead: 'triangle', pad: 'triangle', dens: .8, perc: 1, seed: 141 },
  },
  music(name) {
    if (!this.ctx || this.cur === name) { this.want = name; return; }
    this.want = name; const th = this.themes[name]; if (!th) return;
    this.cur = name; this.th = th; this.step = 0; this.next = this.ctx.currentTime + .1;
    // padrão: 4 compassos × 16 passos
    const r = G.seeded(th.seed), pat = [], bars = 8;
    let deg = 0;
    for (let i = 0; i < 16 * bars; i++) {
      if (i % 16 === 0) deg = [0, 0, 3, 4, 5, 2, 3, 4][Math.floor(i / 16)] % th.sc.length;
      let n = null;
      if (r() < th.dens * (i % 4 === 0 ? 1 : .45)) { deg = (deg + [-2, -1, 0, 1, 2][Math.floor(r() * 5)] + th.sc.length * 4) % th.sc.length; n = deg; }
      pat.push(n);
    }
    this.pat = pat; this.prog = [0, 0, 3, 4, 5, 3, 1, 4].map(d => d % th.sc.length);
    if (this.mus) { const g = this.mus.gain; g.cancelScheduledValues(this.ctx.currentTime); g.setValueAtTime(0.0001, this.ctx.currentTime); g.linearRampToValueAtTime(G.settings.music * .5, this.ctx.currentTime + 1.2); }
  },
  stopMusic() { this.cur = null; this.want = null; },
  midi(n) { return 440 * Math.pow(2, (n - 69) / 12); },
  tick() {
    if (!this.ctx || !this.cur || this.ctx.state !== 'running') return;
    const th = this.th, spb = 60 / th.bpm / 4;
    while (this.next < this.ctx.currentTime + .25) {
      const i = this.step % this.pat.length, bar = Math.floor(i / 16), t = this.next, sc = th.sc, root = th.root;
      const note = (d, oct = 0) => root + sc[d % sc.length] + 12 * (Math.floor(d / sc.length) + oct);
      const n = this.pat[i];
      if (n !== null) { this.tone(t, this.midi(note(n, 1)), spb * (th.bell ? 6 : 2.2), th.lead, th.bell ? .1 : .07, this.mus); if (th.bell) this.tone(t, this.midi(note(n, 2)), spb * 4, 'sine', .04, this.mus); }
      if (i % 16 === 0) { const d = this.prog[bar % 8]; [0, 2, 4].forEach(k => this.tone(t, this.midi(note(d + k, 0)), spb * 15, th.pad, .035, this.mus)); }
      if (i % 8 === 0) this.tone(t, this.midi(note(this.prog[bar % 8], -1)), spb * (th.perc > 1 ? 3 : 7), th.perc > 1 ? 'sawtooth' : 'sine', .1, this.mus);
      if (th.perc >= 1 && i % 4 === 0) this.noise(t, .05, i % 8 === 0 ? .16 : .06, i % 8 === 0 ? 150 : 4000, 1, i % 8 === 0 ? 'lowpass' : 'highpass', this.mus);
      if (th.perc >= 2 && i % 8 === 4) this.noise(t, .1, .14, 1800, 1, 'bandpass', this.mus);
      if (th.perc >= 3 && i % 2 === 0) this.noise(t, .03, .05, 6000, 1, 'highpass', this.mus);
      this.next += spb; this.step++;
    }
  },
  /* ---------- ambiente natural ---------- */
  ambient(name) {
    if (!this.ctx) { this.ambWant = name; return; }
    if (this.ambName === name) return; this.ambName = name;
    if (this.amb_t) clearInterval(this.amb_t);
    if (this.ambSrc) { try { this.ambSrc.stop(); } catch (e) {} this.ambSrc = null; }
    const c = this.ctx;
    const bed = (f, v, type = 'lowpass') => { const s = c.createBufferSource(), fl = c.createBiquadFilter(), g = c.createGain(); s.buffer = this.noiseBuf; s.loop = true; fl.type = type; fl.frequency.value = f; g.gain.value = v; s.connect(fl); fl.connect(g); g.connect(this.amb); s.start(); this.ambSrc = s; };
    const chirp = () => { const t = c.currentTime; const f = 2200 + Math.random() * 1800; for (let i = 0; i < 2 + (Math.random() * 3 | 0); i++) this.tone(t + i * .09, f + Math.random() * 400, .07, 'sine', .08, this.amb, 600); };
    const cricket = () => { const t = c.currentTime; for (let i = 0; i < 6; i++) this.tone(t + i * .05, 4300, .03, 'square', .015, this.amb); };
    const drip = () => this.tone(c.currentTime, 1200 + Math.random() * 600, .2, 'sine', .08, this.amb, -500);
    const crackle = () => this.noise(c.currentTime, .05, .07, 3000 + Math.random() * 2000, 1, 'highpass', this.amb);
    if (name === 'forest') { bed(700, .05); this.amb_t = setInterval(() => Math.random() < .5 && chirp(), 1400); }
    else if (name === 'water') { bed(900, .12); this.amb_t = setInterval(() => Math.random() < .3 && chirp(), 1800); }
    else if (name === 'cave') { bed(250, .08); this.amb_t = setInterval(() => Math.random() < .5 && drip(), 1500); }
    else if (name === 'snow') { bed(1400, .1, 'bandpass'); this.amb_t = null; }
    else if (name === 'night') { bed(500, .03); this.amb_t = setInterval(cricket, 500); }
    else if (name === 'village') { bed(600, .03); this.amb_t = setInterval(() => Math.random() < .4 && chirp(), 1600); }
    else if (name === 'indoor') { bed(200, .02); this.amb_t = setInterval(() => Math.random() < .8 && crackle(), 300); }
    else if (name === 'canyon') { bed(1000, .09, 'bandpass'); }
    else if (name === 'castle') { bed(300, .06); this.amb_t = setInterval(() => Math.random() < .3 && drip(), 2000); }
  }
};
