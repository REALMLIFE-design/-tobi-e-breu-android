/* game.js — núcleo: entrada, mundo, combate, IA, missões, renderização */
(function () {
const cv = document.getElementById('c'), c = cv.getContext('2d');
const TAU = Math.PI * 2, A = G.audio, P2 = G.props;
let S = null, w = null, P = null, cat = null;
let enemies = [], npcs = [], chests = [], picks = [], projs = [], parts = [], floats = [], boss = null;
let cam = 0, T = 0, shake = 0, hitstop = 0, mode = 'boot', battleT = 0, saveT = 0, flash = 0, curMusic = '';
G.get = () => ({ S, w, P, enemies, npcs, mode });
G.inGame = () => mode === 'play';
G.setS = s => { S = s; G.S = s; };

/* ================== ENTRADA ================== */
const IN = G.IN = { held: {}, press: {}, mx: 0, my: 0, tx: 0, ty: 0 };
const KEYMAP = { KeyJ: 'atk', KeyZ: 'atk', KeyK: 'heavy', KeyX: 'heavy', KeyL: 'dodge', ControlLeft: 'dodge', Space: 'jump', KeyF: 'def', Semicolon: 'def', KeyE: 'int', Enter: 'int',
  Digit1: 'sk1', Digit2: 'sk2', Digit3: 'sk3', Digit4: 'sk4', KeyC: 'skc', KeyI: 'inv', KeyM: 'map', KeyQ: 'quest', Escape: 'pause', KeyP: 'pause', ShiftLeft: 'run', ShiftRight: 'run' };
const MOVE = { KeyW: [0, -1], ArrowUp: [0, -1], KeyS: [0, 1], ArrowDown: [0, 1], KeyA: [-1, 0], ArrowLeft: [-1, 0], KeyD: [1, 0], ArrowRight: [1, 0] };
const mvKeys = {};
addEventListener('keydown', e => {
  if (e.target && /INPUT|SELECT/.test(e.target.tagName)) return;
  A.init();
  if (MOVE[e.code]) { mvKeys[e.code] = 1; e.preventDefault(); }
  const a = KEYMAP[e.code]; if (a) { if (!IN.held[a]) IN.press[a] = true; IN.held[a] = true; if (['Space', 'Enter'].includes(e.code)) e.preventDefault(); }
});
addEventListener('keyup', e => { delete mvKeys[e.code]; const a = KEYMAP[e.code]; if (a) IN.held[a] = false; });
addEventListener('blur', () => { for (const k in mvKeys) delete mvKeys[k]; IN.held = {}; });
cv.addEventListener('mousedown', e => { A.init(); if (mode === 'play' && !G.ui.busy() && e.button === 0) IN.press.atk = true; if (e.button === 2) IN.held.def = true; });
cv.addEventListener('mouseup', e => { if (e.button === 2) IN.held.def = false; });
cv.addEventListener('contextmenu', e => e.preventDefault());
G.press = a => { IN.press[a] = true; }; G.hold = (a, v) => { IN.held[a] = v; };
function readMove() {
  let x = 0, y = 0; for (const k in mvKeys) { x += MOVE[k][0]; y += MOVE[k][1]; }
  x += IN.tx; y += IN.ty; const l = Math.hypot(x, y); if (l > 1) { x /= l; y /= l; } IN.mx = x; IN.my = y; return l;
}
function resize() { const s = Math.min(innerWidth / 1280, innerHeight / 720); cv.style.width = 1280 * s + 'px'; cv.style.height = 720 * s + 'px'; const h = document.getElementById('hud'); }
addEventListener('resize', resize); resize();

/* ================== ESTADO / STATS ================== */
function newState() {
  return { lvl: 1, xp: 0, hp: 100, en: 60, coins: 20, inv: { potion_hp: 2, apple: 1 }, eq: { weapon: 'sword_wood', armor: 'tunic', amulet: null }, skills: {}, quests: {}, flags: {}, chests: {}, picks: {}, visited: {},
    area: 'floresta', x: 300, y: 570, t: 0, kills: 0, deaths: 0, intro: false };
}
function stats() {
  const I = G.ITEMS, wp = I[S.eq.weapon] || {}, ar = I[S.eq.armor] || {}, am = (S.eq.amulet && I[S.eq.amulet]) || {}, L = S.lvl - 1;
  return { maxhp: 100 + L * 14 + (am.hp || 0), maxen: 60 + L * 6 + (ar.en || 0) + (am.en || 0), atk: 6 + L * 2.2 + (wp.atk || 0) + (am.atk || 0), def: L * .8 + (ar.def || 0), spd: 1 + (am.spd || 0), cat: 1 + (am.cat || 0) + L * .03 };
}
G.stats = stats;
const xpNeed = l => Math.round(40 * Math.pow(l, 1.55));
G.xpNeed = xpNeed;
function addXP(n) {
  S.xp += n; let up = 0;
  while (S.lvl < 25 && S.xp >= xpNeed(S.lvl)) { S.xp -= xpNeed(S.lvl); S.lvl++; up++; }
  if (up) { const st = stats(); S.hp = st.maxhp; S.en = st.maxen; A.sfx('level'); toast('⭐ Nível ' + S.lvl + '! Vida, energia e força aumentaram.'); sparkle(P.x, P.y - 40, 30, '#ffe27a'); G.ui.hud(); }
}
function toast(t, ms = 2600) { const e = document.getElementById('toast'); e.textContent = t; e.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => e.classList.remove('on'), ms); }
G.toast = toast;
function banner(t, ms = 2600) { const e = document.getElementById('banner'); e.textContent = t; e.classList.add('on'); clearTimeout(banner.t); banner.t = setTimeout(() => e.classList.remove('on'), ms); }
/* inventário */
const inv = id => S.inv[id] || 0;
function give(id, n = 1, quiet) {
  S.inv[id] = inv(id) + n; const it = G.ITEMS[id]; if (!quiet) { toast(`+${n} ${it.n}`); A.sfx('pick'); }
  if (it.t === 'weapon' && (G.ITEMS[S.eq.weapon].atk || 0) < it.atk) S.eq.weapon = id;
  if (it.t === 'armor' && (G.ITEMS[S.eq.armor].def || 0) < it.def) S.eq.armor = id;
  G.ui.hud(); checkQuests();
}
function take(id, n = 1) { S.inv[id] = Math.max(0, inv(id) - n); if (!S.inv[id]) delete S.inv[id]; G.ui.hud(); }
G.give = give; G.take = take; G.inv = inv;
G.useItem = id => { const it = G.ITEMS[id]; if (!inv(id) || it.t !== 'use') return false; const st = stats(); take(id);
  if (it.heal) { S.hp = Math.min(st.maxhp, S.hp + it.heal); floatText(P.x, P.y - 90, '+' + it.heal, '#7dff8a'); } if (it.en) S.en = Math.min(st.maxen, S.en + it.en); A.sfx('heal'); sparkle(P.x, P.y - 40, 14, '#7dff8a'); G.ui.hud(); return true; };
G.equip = id => { const it = G.ITEMS[id]; if (!inv(id)) return; if (it.t === 'weapon') S.eq.weapon = id; else if (it.t === 'armor') S.eq.armor = id; else if (it.t === 'amulet') S.eq.amulet = (S.eq.amulet === id ? null : id);
  const st = stats(); S.hp = Math.min(S.hp, st.maxhp); S.en = Math.min(S.en, st.maxen); A.sfx('ui'); G.ui.hud(); };

/* ================== MISSÕES ================== */
const QM = () => G.QMAP;
function qavail(q) { return !S.quests[q.id] && q.pre.every(p => S.quests[p] && S.quests[p].st === 'done'); }
function qprog(q, i) { const o = q.obj[i], st = S.quests[q.id]; if (!st) return 0; if (o.t === 'item') return Math.min(o.n, inv(o.it)); return Math.min(o.n || 1, st.p[i] || 0); }
function qcomplete(q) { return q.obj.every((o, i) => qprog(q, i) >= (o.n || 1)); }
function checkQuests() {
  if (!S) return;
  for (const q of G.QUESTS) { const st = S.quests[q.id]; if (!st || st.st !== 'active') continue;
    if (qcomplete(q)) { st.st = 'ready'; A.sfx('quest'); toast('✔ Missão pronta: ' + q.t + ' — fale com ' + G.NPC[q.giver].n, 3600); } }
  G.ui.hud();
}
function qevent(type, key) {
  if (!S) return; for (const q of G.QUESTS) { const st = S.quests[q.id]; if (!st || st.st !== 'active') continue;
    q.obj.forEach((o, i) => { if (o.t !== type) return; if (type === 'kill' && o.en === key) st.p[i] = (st.p[i] || 0) + 1; else if (type === 'reach' && o.area === key) st.p[i] = 1; else if (type === 'talk' && o.npc === key) st.p[i] = 1; else if (type === 'boss' && o.boss === key) st.p[i] = 1; }); }
  checkQuests();
}
function acceptQuest(q) { S.quests[q.id] = { st: 'active', p: [] }; if (q.id === 'q28') give('letter', 1, true); A.sfx('quest'); toast('📜 Nova missão: ' + q.t, 3200);
  q.obj.forEach((o, i) => { if (o.t === 'reach' && S.area === o.area) S.quests[q.id].p[i] = 1; }); checkQuests(); }
function finishQuest(q) {
  const st = S.quests[q.id]; st.st = 'done'; q.obj.forEach(o => { if (o.t === 'item') take(o.it, o.n); });
  const r = q.rw || {}; if (r.xp) addXP(r.xp); if (r.coin) { S.coins += r.coin; } (r.items || []).forEach(i => give(i, 1, true));
  if (r.skill) { S.skills[r.skill] = true; toast('✨ Nova habilidade: ' + G.SKILLS[r.skill].n, 4000); }
  if (r.flag) S.flags[r.flag] = true; A.sfx('level'); toast(`Missão concluída: ${q.t}  (+${r.xp || 0} XP, +${r.coin || 0}🪙)`, 4000); G.ui.hud(); saveGame();
}
G.quest = { avail: qavail, prog: qprog, complete: qcomplete, finish: finishQuest, accept: acceptQuest };
function currentObjective() {
  for (const q of G.QUESTS) { const st = S.quests[q.id]; if (st && st.st === 'ready') return { q, txt: 'Fale com ' + G.NPC[q.giver].n }; }
  for (const q of G.QUESTS) { const st = S.quests[q.id]; if (st && st.st === 'active') { const i = q.obj.findIndex((o, k) => qprog(q, k) < (o.n || 1)); return { q, txt: q.obj[i].txt + (q.obj[i].n > 1 ? ` (${qprog(q, i)}/${q.obj[i].n})` : '') }; } }
  for (const q of G.QUESTS) if (qavail(q) && !q.id.startsWith('s')) { return { q: null, txt: 'Fale com ' + G.NPC[q.giver].n + ' (' + areaOfNpc(q.giver) + ')' }; }
  return null;
}
function areaOfNpc(id) { const a = G.AREAS.find(a => (a.npcs || []).some(n => n.id === id)) || G.AREAS.find(a => (a.houses || []).some(h => (G.INTS[h.int].npcs || []).some(n => n.id === id))); return a ? a.n : '?'; }
G.currentObjective = currentObjective;

/* ================== MUNDO ================== */
function depth(y) { return G.lerp(.78, 1.14, G.clamp((y - w.gy[0]) / (w.gy[1] - w.gy[0]), 0, 1)); }
function mkPlayer(x, y) { return { x, y, z: 0, vz: 0, face: 1, st: 'idle', t: 0, ct: 0, combo: 0, comboT: 0, inv: 0, dodgeT: 0, dx: 1, dy: 0, kx: 0, ky: 0, hurtT: 0, blocking: false, bt: 0, step: 0, anim: 0, cd: { 1: 0, 2: 0, 3: 0, 4: 0, c: 0 }, dead: false, atkHit: false, heavyHit: false, spinT: 0, castT: 0 }; }

function enterArea(id, spawn, silent) {
  const def = G.AMAP[id]; S.area = id; S.int = null; w = P2.build(def, S); mode = 'play';
  enemies = []; npcs = []; chests = []; picks = []; projs = []; parts = []; floats = []; boss = null;
  let sx = 90, sy = w.path(90).cy; if (spawn === 'R') { sx = w.W - 90; sy = w.path(sx).cy; } else if (spawn && spawn.x !== undefined) { sx = spawn.x; sy = spawn.y; }
  P = mkPlayer(sx, sy); P.face = spawn === 'R' ? -1 : 1; cam = G.clamp(sx - 640, 0, w.W - 1280);
  cat = { x: sx - 40, y: sy + 8, z: 0, face: 1, st: 'idle', t: 0, cd: 1, tgt: null, fx: 0, anim: 0, leap: 0 };
  // NPCs
  (def.npcs || []).forEach(n => { const nd = G.NPC[n.id]; npcs.push({ id: n.id, def: nd, x: n.x, y: w.path(n.x).cy + 6, face: -1, t: Math.random() * 6 }); });
  // baús
  (def.chests || []).forEach((ch, i) => { const key = id + 'c' + i; const p = w.path(ch.x); chests.push({ key, x: ch.x, y: p.yb - 14, loot: ch.loot, open: !!S.chests[key], t: 0 }); w.obs.push({ x: ch.x, y: p.yb - 14, rx: 26, ry: 8, k: 'chest' }); });
  // coletáveis
  (def.pick || []).forEach((pk, i) => { const key = id + 'p' + i; if (S.picks[key]) return; const p = w.path(pk.x); picks.push({ key, it: pk.it, x: pk.x, y: p.cy + (i % 2 ? 24 : -22), t: Math.random() * 6 }); });
  // inimigos
  if (def.en && def.en.length) { const alive = !def.safe;
    for (let i = 0; i < (def.cnt || 0); i++) { const x = 520 + (w.W - 1000) * (i + .5) / def.cnt + G.rnd(-80, 80), p = w.path(x); spawnEnemy(G.pick(def.en), x, G.rnd(p.yt + 14, p.yb - 8)); } }
  if (def.boss && !S.flags['b_' + def.boss]) { const bx = w.W - 380; const p = w.path(bx); boss = spawnEnemy(def.boss, bx, p.cy, true); }
  if (def.final && !S.flags['b_void_king']) { boss = spawnEnemy('void_king', w.W - 420, w.path(w.W - 420).cy, true); }
  S.visited[id] = true; qevent('reach', id);
  const mus = def.music; setMusic(mus); A.ambient(def.amb);
  if (!silent) banner(def.n); autosave();
  document.getElementById('hud').classList.remove('hidden'); G.ui.hud();
}
const LAYOUT = {
  home:[{k:'table',x:560,y:610},{k:'chair',x:470,y:625},{k:'sack',x:200,y:600},{k:'hay',x:1030,y:565,rest:1},{k:'chest',x:1170,y:650,chest:1}],
  shop:[{k:'barrels',x:200,y:560},{k:'crates',x:1100,y:560},{k:'table',x:640,y:585},{k:'sack',x:330,y:600},{k:'crate',x:960,y:610},{k:'chest',x:1200,y:650,chest:1}],
  smith:[{k:'anvil',x:480,y:620},{k:'logs',x:200,y:570},{k:'crates',x:1000,y:560},{k:'barrel',x:1150,y:600},{k:'chest',x:1200,y:665,chest:1}],
  tavern:[{k:'fire',x:1080,y:560,rest:1},{k:'barrels',x:150,y:560},{k:'table',x:700,y:625},{k:'table',x:420,y:600},{k:'chair',x:880,y:640},{k:'chest',x:1220,y:665,chest:1}],
  tree:[{k:'hay',x:200,y:570,rest:1},{k:'table',x:620,y:610},{k:'sack',x:1060,y:590},{k:'chest',x:1200,y:650,chest:1}],
  hut:[{k:'hay',x:180,y:575,rest:1},{k:'table',x:600,y:600},{k:'crate',x:1080,y:580},{k:'chest',x:1200,y:660,chest:1}],
  hall:[{k:'column',x:300,y:560},{k:'column',x:980,y:560},{k:'fire',x:640,y:570,rest:1},{k:'table',x:1000,y:625},{k:'barrel',x:90,y:600},{k:'chest',x:1210,y:665,chest:1}],
};
function enterInt(key, from) {
  const d = G.INTS[key]; S.int = key; S.ret = from || S.ret;
  w = { interior: true, def: { id: 'int_' + key, n: d.n, bg: d.bg, W: 1280, bi: 'indoor' }, W: 1280, gy: [480, 700], obs: [], furn: [], houses: [], deco: [], fg: [], torches: [], camps: [], water: null };
  w.path = x => ({ yt: 505, yb: 690, cy: 600 });
  (LAYOUT[key] || []).forEach(f => { const fw = P2.FW[f.k] || [30, 10]; const o = { k: f.k, x: f.x, y: f.y, rest: f.rest, chest: f.chest, nc: f.nc }; w.furn.push(o); if (!f.nc && fw[0]) w.obs.push({ x: f.x, y: f.y, rx: fw[0], ry: fw[1], k: 'furn' }); });
  enemies = []; npcs = []; chests = []; picks = []; projs = []; parts = []; floats = []; boss = null;
  d.npcs.forEach(n => { const nd = G.NPC[n.id]; npcs.push({ id: n.id, def: nd, x: n.x, y: 600, face: -1, t: Math.random() * 6 }); w.obs.push({ x: n.x, y: 600, rx: 20, ry: 8, k: 'npc' }); });
  w.furn.filter(f => f.chest).forEach((f, i) => { const k = 'int' + key + i; chests.push({ key: k, x: f.x, y: f.y, loot: d.chest, open: !!S.chests[k], t: 0, fixed: 1 }); });
  P = mkPlayer(640, 668); cat = { x: 600, y: 676, z: 0, face: 1, st: 'idle', t: 0, cd: 1, tgt: null, anim: 0, leap: 0 }; cam = 0; mode = 'play';
  setMusic('village'); A.ambient('indoor'); banner(d.n); G.ui.hud(); autosave();
}
function exitInt() { const r = S.ret || { area: 'vila', x: 300 }; const def = G.AMAP[r.area]; enterArea(r.area, { x: r.x, y: 0 }, true); const p = w.path(r.x); P.y = p.yt + 24; cat.y = P.y + 6; A.sfx('door'); }
function setMusic(m) { curMusic = m; A.music(m); }

/* ================== INIMIGOS ================== */
function spawnEnemy(id, x, y, isBoss) {
  const d = isBoss ? G.BOSS[id] : G.EN[id]; const e = { id, d, boss: !!isBoss, x, y, z: 0, hp: d.hp, mhp: d.hp, face: -1, st: 'idle', t: Math.random() * 2, cd: G.rnd(.5, 1.5), vx: 0, vy: 0, hurt: 0, flash: 0, tele: 0, aggro: false, spr: G.pick(d.spr), bob: Math.random() * 6, phase: 1, pi: 0, ptype: null, pt: 0, sx: x, sy: y, minion: 0, stun: 0, home: x };
  if (d.fly) e.z = d.fly; if (isBoss) { e.cd = 2; e.aggro = false; }
  enemies.push(e); return e;
}
const eRad = e => (e.boss ? Math.min(40, e.d.h * .1) : 14);
function eMove(e, dx, dy) {
  if (e.d.ai === 'flyer') { const p = w.path(e.x + dx); e.x = G.clamp(e.x + dx, 20, w.W - 20); e.y = G.clamp(e.y + dy, p.yt - 40, p.yb + 20); return; }
  const rr = eRad(e), ry = e.boss ? 10 : 6;
  if (P2.walkable(w, e.x + dx, e.y + dy, rr, ry)) { e.x += dx; e.y += dy; } else if (P2.walkable(w, e.x + dx, e.y, rr, ry)) e.x += dx; else if (P2.walkable(w, e.x, e.y + dy, rr, ry)) e.y += dy;
}
function enemyAI(e, dt) {
  const d = e.d, dx = P.x - e.x, dy = P.y - e.y, dist = Math.hypot(dx, dy * 2), spd = d.spd * (e.boss && e.phase > 1 ? 1.2 : 1) * (e.stun > 0 ? 0 : 1);
  e.t += dt; e.hurt = Math.max(0, e.hurt - dt); e.flash = Math.max(0, e.flash - dt); e.stun = Math.max(0, e.stun - dt); e.cd -= dt;
  e.x += e.vx * dt; e.y += e.vy * dt; e.vx *= .86; e.vy *= .86;
  if (e.hurt > 0 || e.stun > 0) { e.face = dx > 0 ? 1 : -1; return; }
  if (P.dead) { e.aggro = false; }
  else if (!e.aggro && dist < (e.boss ? 640 : 360)) { e.aggro = true; if (e.boss) { A.sfx('roar'); banner(d.n, 3000); shake = 14; } else if (d.snd) A.sfx(d.snd); }
  if (!e.aggro) { // patrulha leve
    if (e.st !== 'patrol' && e.cd < 0) { e.st = 'patrol'; e.pt = G.rnd(.8, 2); e.px = G.rnd(-1, 1); e.py = G.rnd(-.5, .5); e.cd = G.rnd(1.5, 3); }
    if (e.st === 'patrol') { e.pt -= dt; eMove(e, e.px * spd * .3 * dt, e.py * spd * .3 * dt); if (e.px) e.face = e.px > 0 ? 1 : -1; if (e.pt < 0) e.st = 'idle'; }
    return;
  }
  e.face = dx > 0 ? 1 : -1;
  if (e.boss) return bossAI(e, dt, dx, dy, dist);
  const ai = d.ai;
  if (e.st === 'wind') { e.tele -= dt; if (e.tele <= 0) { e.st = 'strike'; e.tele = .18; e.hitDone = false; if (ai === 'flyer') { e.fx = dx / Math.max(1, dist) * 420; e.fy = dy / Math.max(1, dist) * 300; } } return; }
  if (e.st === 'strike') { e.tele -= dt;
    if (ai === 'melee') { if (!e.hitDone && dist < d.rng * 1.3) { e.hitDone = true; hurtPlayer(d.atk * (.9 + Math.random() * .2), e); } }
    else if (ai === 'flyer') { e.x += e.fx * dt; e.y += e.fy * dt; if (!e.hitDone && dist < d.rng + 8 && P.z < 40) { e.hitDone = true; hurtPlayer(d.atk, e); } }
    else if (ai === 'ranged') { if (!e.hitDone) { e.hitDone = true; const a = Math.atan2(dy, dx); projs.push({ x: e.x, y: e.y, z: 40, vx: Math.cos(a) * 340, vy: Math.sin(a) * 340 * .5, from: 'e', k: 'spear', dmg: d.atk, life: 2, r: 14, ang: a }); A.sfx('swing'); } }
    else if (ai === 'caster') { if (!e.hitDone) { e.hitDone = true; castOrb(e, d.atk); } }
    if (e.tele <= 0) { e.st = 'rec'; e.tele = (ai === 'flyer' ? .9 : .7); } return; }
  if (e.st === 'rec') { e.tele -= dt; if (e.tele <= 0) e.st = 'chase'; if (ai === 'flyer') { eMove(e, -dx * .3 * dt, -dy * .3 * dt); } return; }
  // perseguir / manter distância
  const keep = ai === 'ranged' ? 230 : ai === 'caster' ? 270 : 0;
  let mx = dx / Math.max(1, dist), my = dy / Math.max(1, dist) * .5;
  if (keep) { if (dist < keep - 40) { mx = -mx; my = -my; } else if (dist < keep + 60) { mx = 0; my = 0; } }
  if (ai === 'flyer') { e.bob += dt * 5; e.z = d.fly + Math.sin(e.bob) * 14; }
  eMove(e, mx * spd * dt, my * spd * dt);
  // outros inimigos: separação
  for (const o of enemies) if (o !== e && !o.boss) { const ox = e.x - o.x, oy = e.y - o.y; if (Math.abs(ox) < 30 && Math.abs(oy) < 14) eMove(e, Math.sign(ox || 1) * 20 * dt, Math.sign(oy || 1) * 10 * dt); }
  const inRange = ai === 'melee' || ai === 'flyer' ? dist < d.rng : (dist < d.rng && dist > keep - 80);
  if (inRange && e.cd <= 0 && !P.dead) { e.st = 'wind'; e.tele = ai === 'melee' ? (d.slow ? .65 : .42) : ai === 'flyer' ? .5 : .55; e.cd = ai === 'ranged' || ai === 'caster' ? G.rnd(1.7, 2.4) : G.rnd(.9, 1.5); }
}
function castOrb(e, dmg) { const dx = P.x - e.x, dy = P.y - e.y, a = Math.atan2(dy, dx); projs.push({ x: e.x, y: e.y, z: 60, vx: Math.cos(a) * 200, vy: Math.sin(a) * 200 * .5, from: 'e', k: 'orb', dmg, life: 3.5, r: 16, home: 1 }); A.sfx('magic'); }
/* ------- chefes ------- */
function bossAI(e, dt, dx, dy, dist) {
  const d = e.d, hpR = e.hp / e.mhp, ph = d.void ? (hpR < .34 ? 3 : hpR < .67 ? 2 : 1) : (hpR < .5 ? 2 : 1);
  if (ph > e.phase) { e.phase = ph; e.st = 'phase'; e.tele = 1.4; e.cd = 0; shake = 22; A.sfx('roar'); banner(ph === 3 ? 'FASE FINAL' : 'FÚRIA!', 1800); e.invuln = 1.4; spawnMinions(e, 2); }
  if (e.invuln > 0) e.invuln -= dt;
  const pats = d.pat.concat(ph > 1 ? d.ph2 : []);
  const spd = d.spd * (ph > 1 ? 1.2 : 1);
  switch (e.st) {
    case 'phase': e.tele -= dt; if (e.tele <= 0) e.st = 'chase'; return;
    case 'tele': { e.tele -= dt; if (e.ptype === 'charge' && e.tele > .1) { e.dir = Math.atan2(dy, dx); } if (e.tele <= 0) startPattern(e, ph); return; }
    case 'act': { e.pt -= dt; runPattern(e, dt, ph); if (e.pt <= 0) { e.st = 'rec'; e.tele = ph > 1 ? .7 : 1.1; } return; }
    case 'rec': e.tele -= dt; if (e.tele <= 0) e.st = 'chase'; return;
  }
  // chase / melee leve
  const mx = dx / Math.max(1, dist), my = dy / Math.max(1, dist) * .5; if (dist > 120) eMove(e, mx * spd * dt, my * spd * dt);
  e.bob += dt * 4;
  if (e.cd <= 0) { e.ptype = G.pick(pats); if (e.ptype === 'summon' && enemies.filter(o => o.minion).length > 4) e.ptype = 'slam'; if (e.ptype === 'charge' && dist < 150) e.ptype = 'slam';
    e.st = 'tele'; e.tele = e.ptype === 'slam' ? 1 : e.ptype === 'charge' ? .8 : e.ptype === 'spin' ? .6 : .7; e.cd = ph > 1 ? G.rnd(.3, .8) : G.rnd(.9, 1.6); e.tx = P.x; e.ty = P.y; A.sfx('warn');
    if (e.ptype === 'teleport') { e.alpha = 1; } }
}
function startPattern(e, ph) {
  e.st = 'act'; const d = e.d;
  switch (e.ptype) {
    case 'charge': e.pt = .7; e.hitDone = false; break;
    case 'slam': e.pt = .5; e.boom = false; e.bt = .0; break;
    case 'fan': { e.pt = .5; const n = ph > 1 ? 9 : 5, a0 = Math.atan2(P.y - e.y, P.x - e.x); for (let i = 0; i < n; i++) { const a = a0 + (i - (n - 1) / 2) * .22; projs.push({ x: e.x, y: e.y, z: 60, vx: Math.cos(a) * 300, vy: Math.sin(a) * 300 * .5, from: 'e', k: d.caster ? 'orb' : 'spear', dmg: d.atk * .6, life: 3, r: 14, ang: a }); } A.sfx(d.caster ? 'fire' : 'swing'); break; }
    case 'summon': e.pt = .6; spawnMinions(e, ph > 1 ? 3 : 2); A.sfx('roar'); break;
    case 'spin': e.pt = 1.4; e.sp = 0; e.hitT = 0; A.sfx('spin'); break;
    case 'teleport': e.pt = .6; { const a = G.rnd(0, TAU); const nx = G.clamp(P.x + Math.cos(a) * 140, 60, w.W - 60), ny = w.path(nx).cy; e.x = nx; e.y = ny; e.z = 0; sparkle(e.x, e.y - 60, 20, '#ff4a8a'); A.sfx('magic'); e.hitDone = false; } break;
  }
}
function runPattern(e, dt, ph) {
  const d = e.d, dist = Math.hypot(P.x - e.x, (P.y - e.y) * 2);
  if (e.ptype === 'charge') { const sp = 560; eMove(e, Math.cos(e.dir) * sp * dt, Math.sin(e.dir) * sp * dt * .5); if (!e.hitDone && dist < e.d.h * .35 + 30) { e.hitDone = true; hurtPlayer(d.atk * 1.4, e, 360); } }
  else if (e.ptype === 'slam') { if (!e.boom && e.pt < .3) { e.boom = true; shake = 18; A.sfx('slam'); const R = 170; ring(e.x, e.y, R); if (dist < R + 10 && P.z < 30) hurtPlayer(d.atk * 1.6, e, 300); enemies.forEach(() => { }); } }
  else if (e.ptype === 'spin') { e.sp += dt * 14; e.hitT -= dt; if (e.hitT <= 0 && dist < 150 + e.d.h * .12 && P.z < 30) { e.hitT = .35; hurtPlayer(d.atk * .9, e, 260); } }
  else if (e.ptype === 'teleport') { if (!e.hitDone && e.pt < .35) { e.hitDone = true; shake = 8; if (dist < 140) hurtPlayer(d.atk * 1.2, e, 260); ring(e.x, e.y, 120); A.sfx('slam'); } }
}
function spawnMinions(e, n) { const d = e.d; if (!d.sum) return; for (let i = 0; i < n; i++) { const x = G.clamp(e.x + G.rnd(-220, 220), 60, w.W - 60), p = w.path(x); const m = spawnEnemy(d.sum, x, G.rnd(p.yt + 10, p.yb - 6)); m.minion = 1; m.aggro = true; sparkle(m.x, m.y - 30, 10, '#fff'); } }
function ring(x, y, R) { parts.push({ k: 'ring', x, y, z: 0, life: .5, max: .5, R }); }

/* ================== DANO ================== */
function hurtEnemy(e, dmg, kx, ky, o = {}) {
  if (e.dead || e.invuln > 0) return; const st = stats(); const crit = Math.random() < .12; dmg = Math.max(1, Math.round(dmg * (.88 + Math.random() * .24) * (crit ? 1.7 : 1)));
  e.hp -= dmg; e.flash = .14; e.aggro = true; if (!e.boss) { e.hurt = o.stun || .28; e.vx = kx; e.vy = ky * .4; e.st = 'idle'; } else { e.vx = kx * .15; e.vy = ky * .05; if (o.stun) e.stun = Math.min(o.stun, 1.2); }
  floatText(e.x, e.y - e.d.h * .8 - e.z, dmg + (crit ? '!' : ''), crit ? '#ffe27a' : '#fff'); A.sfx(crit ? 'crit' : 'hit'); hitstop = Math.max(hitstop, crit ? .09 : .05); shake = Math.max(shake, e.boss ? 3 : 5);
  sparkle(e.x, e.y - e.d.h * .5 - e.z, 6, '#fff');
  if (e.hp <= 0) killEnemy(e);
}
function killEnemy(e) {
  e.dead = true; e.deadT = .5; const d = e.d; S.kills++; addXP(Math.round(d.xp * (e.minion ? .4 : 1))); const coin = G.irnd(d.coin[0], d.coin[1]); S.coins += coin; if (coin) floatText(e.x, e.y - 20, '+' + coin + '🪙', '#ffd45e');
  A.sfx(e.boss ? 'bossdie' : 'die'); if (e.boss) { shake = 30; sparkle(e.x, e.y - 60, 60, '#ffd45e'); }
  (d.drops || []).forEach(([it, ch]) => { if (Math.random() < ch) { const a = give(it, 1, true); toast('Item encontrado: ' + G.ITEMS[it].n); } });
  if (e.boss) { S.flags['b_' + e.id] = true; S.flags[e.id] = true; qevent('boss', e.id); banner('✦ ' + d.n + ' derrotado ✦', 3600); saveGame();
    if (G.AMAP[S.area].final) setTimeout(() => G.ui.ending(), 3500); }
  else { qevent('kill', e.id); }
  G.ui.hud();
}
function hurtPlayer(dmg, src, kb = 180) {
  if (P.dead || P.inv > 0 || P.dodgeT > 0) return false; const st = stats();
  let m = 1, perfect = false;
  if (P.blocking && src && ((src.x - P.x) * P.face > -20)) { if (P.bt < .2) { perfect = true; m = 0; } else m = .15; }
  let d = Math.max(1, Math.round((dmg - st.def * .6) * m * (.9 + Math.random() * .2))); if (m === 0) d = 0;
  if (perfect) { A.sfx('block'); floatText(P.x, P.y - 100, 'DEFESA PERFEITA', '#8fe8ff'); if (src && !src.boss) { src.stun = 1; src.vx = -P.face * 260; } S.en = Math.min(st.maxen, S.en + 12); sparkle(P.x + P.face * 30, P.y - 50, 14, '#8fe8ff'); hitstop = .08; return false; }
  if (m < 1) { A.sfx('block'); sparkle(P.x + P.face * 30, P.y - 50, 8, '#ffd45e'); } else { A.sfx('hurt'); P.st = 'hurt'; P.hurtT = .3; }
  S.hp -= d; P.inv = .7; flash = .25; shake = Math.max(shake, 8); floatText(P.x, P.y - 100, '-' + d, '#ff6b5e');
  if (src) { const a = Math.atan2((P.y - src.y) * 2, P.x - src.x); P.kx = Math.cos(a) * kb * (m < 1 ? .4 : 1); P.ky = Math.sin(a) * kb * .25 * (m < 1 ? .4 : 1); }
  if (S.hp <= 0) { S.hp = 0; P.dead = true; P.st = 'die'; P.t = 0; A.sfx('die'); S.deaths++; setTimeout(() => G.ui.death(), 1400); }
  G.ui.hud(); return true;
}
function floatText(x, y, t, col) { floats.push({ x, y, t, col, life: 1, vy: -40 }); }
function sparkle(x, y, n, col) { if (!G.settings.particles && n > 6) n = 4; for (let i = 0; i < n; i++) { const a = Math.random() * TAU, s = G.rnd(40, 220); parts.push({ k: 'sp', x, y: y, z: 0, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life: G.rnd(.3, .7), max: .7, col, r: G.rnd(1.5, 3.5), g: 300 }); } }
G.hurtEnemy = hurtEnemy;

/* ================== JOGADOR ================== */
const WP_COL = { sword_wood: '#a6713a', sword_iron: '#c4c8d0', sword_steel: '#e8eef6', sword_elf: '#9ff0ff', sword_ruby: '#ff6a7a', sword_master: '#ffe27a' };
function hitArc(range, ang, dmg, kb, o = {}) {
  let n = 0; enemies.forEach(e => { if (e.dead) return; const dx = e.x - P.x, dy = (e.y - P.y); const r = range + (e.boss ? e.d.h * .18 : 8);
    if (Math.hypot(dx, dy * 2.2) < r && (ang === 360 || dx * P.face > -18) && P.z < 50) { hurtEnemy(e, dmg, Math.sign(dx || P.face) * kb, Math.sign(dy) * kb * .4, o); n++; } });
  return n;
}
function useSkill(k) {
  if (P.dead) return; const st = stats(), sk = G.SKILLS[k === 'c' ? 'claw' : ['spin', 'fire', 'heal', 'thunder'][k - 1]], id = k === 'c' ? 'claw' : ['spin', 'fire', 'heal', 'thunder'][k - 1];
  if (!S.skills[id]) { toast('Habilidade ainda não aprendida.'); return; } if (P.cd[k] > 0) return; if (S.en < sk.cost) { A.sfx('no'); toast('Energia insuficiente'); return; }
  S.en -= sk.cost; P.cd[k] = sk.cd; const atk = st.atk;
  if (id === 'spin') { P.st = 'spin'; P.spinT = .6; P.t = 0; A.sfx('spin'); P.hitSpin = false; }
  else if (id === 'fire') { P.st = 'cast'; P.t = 0; P.castT = .3; A.sfx('fire'); projs.push({ x: P.x + P.face * 30, y: P.y, z: 50, vx: P.face * 520, vy: 0, from: 'p', k: 'fire', dmg: atk * 2.4 + 8, life: 1.6, r: 22, pierce: 0 }); }
  else if (id === 'heal') { P.st = 'cast'; P.t = 0; P.castT = .5; const h = Math.round(st.maxhp * .4); S.hp = Math.min(st.maxhp, S.hp + h); A.sfx('heal'); floatText(P.x, P.y - 100, '+' + h, '#7dff8a'); parts.push({ k: 'ring', x: P.x, y: P.y, z: 0, life: .8, max: .8, R: 90, col: '#7dff8a' }); sparkle(P.x, P.y - 40, 24, '#7dff8a'); }
  else if (id === 'thunder') { P.st = 'cast'; P.t = 0; P.castT = .5; A.sfx('thunder'); flash = .3; shake = 14; enemies.filter(e => !e.dead && Math.hypot(e.x - P.x, (e.y - P.y) * 2) < 420).slice(0, 8).forEach((e, i) => setTimeout(() => { if (!e.dead && mode === 'play') { parts.push({ k: 'bolt', x: e.x, y: e.y, z: 0, life: .35, max: .35 }); hurtEnemy(e, atk * 3.2 + 12, 0, 0, { stun: .8 }); } }, i * 120)); }
  else if (id === 'claw') { const tg = nearestEnemy(P.x, P.y, 520); if (!tg) { P.cd[k] = 0; S.en += sk.cost; toast('Sem alvo próximo.'); return; } cat.st = 'claw'; cat.tgt = tg; cat.t = 0; cat.hit = false; A.sfx('meow'); }
  G.ui.hud();
}
function nearestEnemy(x, y, r) { let b = null, bd = r; enemies.forEach(e => { if (e.dead) return; const d = Math.hypot(e.x - x, (e.y - y) * 2); if (d < bd) { bd = d; b = e; } }); return b; }
function updatePlayer(dt) {
  const st = stats(); P.t += dt; P.inv = Math.max(0, P.inv - dt); P.comboT = Math.max(0, P.comboT - dt); P.hurtT = Math.max(0, P.hurtT - dt);
  for (const k in P.cd) P.cd[k] = Math.max(0, P.cd[k] - dt);
  if (P.dead) { P.t += dt; return; }
  const ml = readMove(), run = IN.held.run || ml > .85 && IN.joy; const base = 190 * st.spd * (run ? 1.55 : 1);
  P.blocking = !!IN.held.def && !['atk', 'heavy', 'spin', 'cast', 'dodge'].includes(P.st) && P.z === 0;
  if (P.blocking) P.bt += dt; else P.bt = 0;
  // knockback
  if (Math.abs(P.kx) > 5 || Math.abs(P.ky) > 5) { pMove(P.kx * dt, P.ky * dt); P.kx *= .86; P.ky *= .86; }
  // regen
  S.en = Math.min(st.maxen, S.en + (P.blocking ? 0 : 3.2) * dt);
  let busy = false;
  switch (P.st) {
    case 'atk': case 'heavy': {
      busy = true; const dur = P.st === 'atk' ? .3 : .55, hit = P.st === 'atk' ? .38 : .62;
      if (P.t > dur * hit && !P.hitDone) { P.hitDone = true; const mult = P.st === 'atk' ? [1, 1.1, 1.7][P.combo] : 2.6;
        const n = hitArc(P.st === 'atk' ? 96 : 130, 180, st.atk * mult, P.st === 'atk' ? 150 : 320, P.st === 'heavy' ? { stun: .7 } : {}); if (!n) A.sfx('swing'); else { S.en = Math.min(st.maxen, S.en + 2); }
        parts.push({ k: 'slash', x: P.x + P.face * 40, y: P.y, z: 50, face: P.face, life: .22, max: .22, big: P.st === 'heavy' || P.combo === 2, col: WP_COL[S.eq.weapon] || '#fff' }); }
      pMove(P.face * (P.st === 'heavy' ? 60 : 90) * dt * (P.t < dur * .5 ? 1 : 0), 0);
      if (P.t > dur) { P.st = 'idle'; P.comboT = .35; } break; }
    case 'spin': busy = true; P.spinT -= dt; if (!P.hitSpin && P.t > .2) { P.hitSpin = true; hitArc(150, 360, st.atk * 2.2, 280); parts.push({ k: 'ring', x: P.x, y: P.y, z: 0, life: .4, max: .4, R: 150, col: '#fff' }); shake = 8; } if (P.spinT <= 0) P.st = 'idle'; break;
    case 'cast': busy = true; P.castT -= dt; if (P.castT <= 0) P.st = 'idle'; break;
    case 'dodge': busy = true; P.dodgeT -= dt; { const sp = 560; pMove(P.dx * sp * dt, P.dy * sp * dt * .5); if (G.settings.particles && Math.random() < .5) parts.push({ k: 'sp', x: P.x, y: P.y - 20, z: 0, vx: 0, vy: -20, life: .3, max: .3, col: '#ffffff88', r: 6, g: 0 }); } if (P.dodgeT <= 0) P.st = 'idle'; break;
    case 'hurt': busy = P.hurtT > 0; if (!busy) P.st = 'idle'; break;
    case 'cheer': case 'talk': busy = false; break;
  }
  // pulo
  if (P.z > 0 || P.vz) { P.vz -= 1500 * dt; P.z += P.vz * dt; if (P.z <= 0) { P.z = 0; P.vz = 0; A.sfx('land'); if (P.st === 'jump') P.st = 'idle'; } }
  if (!busy) {
    if (IN.press.dodge && P.z === 0 && S.en >= 8) { S.en -= 8; P.st = 'dodge'; P.dodgeT = .28; P.t = 0; P.inv = .32; const l = Math.hypot(IN.mx, IN.my); P.dx = l > .2 ? IN.mx / l : P.face; P.dy = l > .2 ? IN.my / l : 0; if (Math.abs(P.dx) > .1) P.face = P.dx > 0 ? 1 : -1; A.sfx('dodge'); }
    else if (IN.press.atk && !P.blocking) { if (P.comboT > 0) P.combo = (P.combo + 1) % 3; else P.combo = 0; P.st = 'atk'; P.t = 0; P.hitDone = false; A.sfx(P.combo === 2 ? 'swing2' : 'swing'); faceNearest(); }
    else if (IN.press.heavy && S.en >= 6) { S.en -= 6; P.st = 'heavy'; P.t = 0; P.hitDone = false; A.sfx('swing2'); faceNearest(); }
    else if (IN.press.jump && P.z === 0) { P.vz = 560; P.st = 'jump'; A.sfx('jump'); }
    else if (IN.press.sk1) useSkill(1); else if (IN.press.sk2) useSkill(2); else if (IN.press.sk3) useSkill(3); else if (IN.press.sk4) useSkill(4); else if (IN.press.skc) useSkill('c');
    // movimento
    if (!P.blocking || true) { const sp = P.blocking ? base * .45 : base; if (ml > .05) { pMove(IN.mx * sp * dt, IN.my * sp * dt * .62); if (Math.abs(IN.mx) > .15) P.face = IN.mx > 0 ? 1 : -1;
        if (P.z === 0 && P.st !== 'jump') { P.st = P.blocking ? 'def' : run ? 'run' : 'walk'; P.step += dt * (run ? 11 : 7.5); if (P.step > Math.PI) { P.step = 0; if (S.area && !(w.interior)) A.sfx(w.def.bi === 'water' ? 'stepw' : 'step'); else A.sfx('step'); } } }
      else if (P.z === 0 && P.st !== 'jump' && !['cheer', 'talk'].includes(P.st)) P.st = P.blocking ? 'def' : 'idle'; }
    if (P.blocking && P.st === 'idle') P.st = 'def';
  }
  if (P.st === 'def' && !P.blocking) P.st = 'idle';
  // interação
  if (IN.press.int) interact();
  // limites de saída
  if (!w.interior) { if (P.x >= w.W - 16) exitArea(1); else if (P.x <= 16) exitArea(-1); }
  else if (P.y >= 686 && Math.abs(P.x - 640) < 90 && P.st !== 'dodge') { P.x = 640; exitInt(); }
}
function faceNearest() { const e = nearestEnemy(P.x, P.y, 170); if (e) P.face = e.x > P.x ? 1 : -1; }
function pMove(dx, dy) { const rx = 12, ry = 6; if (P2.walkable(w, P.x + dx, P.y + dy, rx, ry)) { P.x += dx; P.y += dy; } else if (P2.walkable(w, P.x + dx, P.y, rx, ry)) P.x += dx; else if (P2.walkable(w, P.x, P.y + dy, rx, ry)) P.y += dy;
  if (w.interior) { P.y = G.clamp(P.y, 505, 690); P.x = G.clamp(P.x, 40, 1240); } }
let lockMsgT = 0;
function exitArea(dir) {
  const def = G.AMAP[S.area], i = def.i;
  if (dir > 0) { const next = G.AREAS[i + 1]; if (!next) { P.x = w.W - 20; return; }
    if (def.gate && !S.flags[def.gate]) { P.x = w.W - 22; P.kx = -200; if (T - lockMsgT > 2) { lockMsgT = T; A.sfx('no'); toast(gateMsg(def)); } return; }
    if (boss && !boss.dead && boss.aggro) { P.x = w.W - 22; P.kx = -200; if (T - lockMsgT > 2) { lockMsgT = T; toast('Não dá para fugir de uma luta de chefe!'); } return; }
    fadeTo(() => enterArea(next.id, 'L'), 'right'); }
  else { const prev = G.AREAS[i - 1]; if (!prev) { P.x = 24; P.kx = 200; if (T - lockMsgT > 2) { lockMsgT = T; toast('Não há volta: o mundo todo aguarda.'); } return; } fadeTo(() => enterArea(prev.id, 'R'), 'left'); }
}
function gateMsg(def) { return ({ rat_king: 'O Rei dos Ratos bloqueia a passagem.', bridge: 'A ponte está quebrada. Fale com o carpinteiro (Missão: Ponte Quebrada).', ogre_forest: 'O Ogro Lenhador guarda o caminho.', goblin_king: 'O Rei Goblin domina a gruta.', key_iron: 'O portão está trancado. Precisa da Chave de Ferro (missão da Batedora).', ice_guardian: 'O Guardião de Gelo bloqueia o pico.', stone_sentinel: 'A Sentinela de Pedra bloqueia o arco.', warlock: 'Rubor guarda a torre.', captain: 'O Capitão Sombrio guarda a masmorra.', warlock2: 'Rubor, Corrompido, bloqueia a saída do templo.' })[def.gate] || 'O caminho está bloqueado.'; }
let fading = false;
function fadeTo(fn, dir) { if (fading) return; fading = true; const f = document.getElementById('fade'); f.style.opacity = 1; setTimeout(() => { fn(); setTimeout(() => { f.style.opacity = 0; fading = false; }, 120); }, 520); }
G.fadeTo = fadeTo;

/* ================== INTERAÇÃO ================== */
function nearInteract() {
  let best = null, bd = 95; const add = (o, d, kind, label) => { if (d < bd) { bd = d; best = { o, kind, label }; } };
  npcs.forEach(n => add(n, Math.hypot(n.x - P.x, (n.y - P.y) * 2), 'npc', 'Falar com ' + n.def.n));
  chests.forEach(ch => { if (!ch.open) add(ch, Math.hypot(ch.x - P.x, (ch.y - P.y) * 2), 'chest', 'Abrir baú'); });
  w.houses.forEach(h => add(h, Math.hypot(h.x - P.x, (h.y + 10 - P.y) * 1.2), 'door', 'Entrar: ' + h.name));
  if (w.interior) { (w.furn || []).filter(f => f.rest).forEach(f => add(f, Math.hypot(f.x - P.x, (f.y - P.y) * 2) - 30, 'rest', f.k === 'hay' ? 'Descansar no feno e salvar' : 'Descansar ao fogo e salvar')); if (P.y > 650 && Math.abs(P.x - 640) < 120) add({}, 40, 'exit', 'Sair'); }
  return best;
}
function interact() {
  const n = nearInteract(); if (!n) return; const o = n.o;
  if (n.kind === 'npc') talkNpc(o);
  else if (n.kind === 'chest') { o.open = true; S.chests[o.key] = true; A.sfx('chest'); const coin = G.irnd(15, 60) * (1 + S.lvl * .2) | 0; S.coins += coin; toast('Baú: +' + coin + '🪙 ' + o.loot.map(i => '· ' + G.ITEMS[i].n).join(' ')); o.loot.forEach(i => give(i, 1, true)); sparkle(o.x, o.y - 30, 20, '#ffd45e'); G.ui.hud(); }
  else if (n.kind === 'door') { A.sfx('door'); const x = o.x; fadeTo(() => enterInt(o.int, { area: S.area, x })); }
  else if (n.kind === 'rest') { fadeTo(() => { const st = stats(); S.hp = st.maxhp; S.en = st.maxen; saveGame(); toast('Descansou e salvou o jogo. 💾'); G.ui.hud(); }); A.sfx('heal'); }
  else if (n.kind === 'exit') exitInt();
}
function talkNpc(n) {
  const nd = n.def, id = n.id; P.face = n.x > P.x ? 1 : -1; n.face = -P.face;
  const Qs = G.QUESTS;
  const ready = Qs.find(q => q.giver === id && S.quests[q.id] && S.quests[q.id].st === 'ready');
  if (ready) { G.ui.say(nd.n, ready.done, nd.spr, () => finishQuest(ready), nd.hue); return; }
  const talk = Qs.find(q => S.quests[q.id] && S.quests[q.id].st === 'active' && q.obj.some((o, i) => o.t === 'talk' && o.npc === id && !S.quests[q.id].p[i]));
  if (talk) { qevent('talk', id); G.ui.say(nd.n, [G.pick(nd.lines)], nd.spr, null, nd.hue); return; }
  const av = Qs.find(q => q.giver === id && qavail(q));
  if (av) { G.ui.say(nd.n, av.intro, nd.spr, () => acceptQuest(av), nd.hue); return; }
  const act = Qs.find(q => q.giver === id && S.quests[q.id] && S.quests[q.id].st === 'active');
  if (act) { const i = act.obj.findIndex((o, k) => qprog(act, k) < (o.n || 1)); G.ui.say(nd.n, ['Ainda falta: ' + (act.obj[i] ? act.obj[i].txt : '...') + '. ' + G.pick(nd.lines)], nd.spr, null, nd.hue); return; }
  if (nd.shop) { G.ui.say(nd.n, [G.pick(nd.lines)], nd.spr, () => G.ui.shop(nd.shop, nd.n), nd.hue); return; }
  G.ui.say(nd.n, [G.pick(nd.lines)], nd.spr, null, nd.hue);
}
function npcMarker(n) { const id = n.id; if (G.QUESTS.some(q => q.giver === id && S.quests[q.id] && S.quests[q.id].st === 'ready')) return '?'; if (G.QUESTS.some(q => S.quests[q.id] && S.quests[q.id].st === 'active' && q.obj.some((o, i) => o.t === 'talk' && o.npc === id && !S.quests[q.id].p[i]))) return '!'; if (G.QUESTS.some(q => q.giver === id && qavail(q))) return '!'; return null; }

/* ================== GATO ================== */
function updateCat(dt) {
  const st = stats(); cat.t += dt; cat.cd -= dt;
  if (cat.st === 'claw') { const tg = cat.tgt; if (!tg || tg.dead) { cat.st = 'idle'; return; } const dx = tg.x - cat.x, dy = tg.y - cat.y, d = Math.hypot(dx, dy * 2); cat.face = dx > 0 ? 1 : -1;
    if (d > 40) { const sp = 700; cat.x += dx / d * sp * dt; cat.y += dy / (d) * sp * dt * .5; cat.z = Math.sin(Math.min(1, cat.t * 2.2) * Math.PI) * 50; }
    else if (!cat.hit) { cat.hit = true; A.sfx('catclaw'); hurtEnemy(tg, stats().atk * 3.2 * st.cat, cat.face * 200, 0, { stun: 1.6 }); parts.push({ k: 'claw', x: tg.x, y: tg.y, z: 40, life: .35, max: .35 }); cat.t = 0; }
    if (cat.hit && cat.t > .3) { cat.st = 'idle'; cat.z = 0; } return; }
  if (cat.st === 'leap') { const tg = cat.tgt; if (!tg || tg.dead) { cat.st = 'idle'; return; } const dx = tg.x - cat.x, dy = tg.y - cat.y, d = Math.hypot(dx, dy * 2); cat.face = dx > 0 ? 1 : -1;
    if (d > 36) { cat.x += dx / d * 460 * dt; cat.y += dy / d * 460 * dt * .5; cat.z = Math.sin(Math.min(1, cat.t * 2) * Math.PI) * 30; } else { A.sfx('catclaw'); hurtEnemy(tg, st.atk * .9 * st.cat, cat.face * 120, 0); cat.st = 'idle'; cat.cd = 1.3; cat.z = 0; parts.push({ k: 'claw', x: tg.x, y: tg.y, z: 30, life: .3, max: .3 }); } return; }
  // seguir o jogador
  const tx = P.x - P.face * 56, ty = P.y + 10; const dx = tx - cat.x, dy = ty - cat.y, d = Math.hypot(dx, dy);
  if (d > 600) { cat.x = tx; cat.y = ty; }
  const run = d > 150; const sp = run ? 360 : 190;
  if (d > 14) { let mx = dx / d * sp * dt, my = dy / d * sp * dt; const nx = cat.x + mx, ny = cat.y + my; if (w.interior ? true : P2.walkable(w, nx, ny, 6, 4)) { cat.x = nx; cat.y = ny; } else { cat.x += mx * .5; cat.y = G.lerp(cat.y, w.path(cat.x).cy, .04); } cat.st = run ? 'run' : 'walk'; if (Math.abs(dx) > 6) cat.face = dx > 0 ? 1 : -1; } else { cat.st = 'idle'; cat.face = P.face; }
  if (!w.interior) { const p = w.path(cat.x); cat.y = G.clamp(cat.y, p.yt - 2, p.yb + 6); }
  // ataque automático
  if (cat.cd <= 0 && !P.dead) { const e = nearestEnemy(cat.x, cat.y, 210); if (e) { cat.st = 'leap'; cat.tgt = e; cat.t = 0; cat.cd = 99; if (Math.random() < .5) A.sfx('meow'); } }
}

/* ================== PROJÉTEIS / PARTÍCULAS ================== */
function updateProjs(dt) {
  projs = projs.filter(p => { p.life -= dt; if (p.life <= 0) return false;
    if (p.home) { const a = Math.atan2(P.y - p.y, P.x - p.x), sp = 190; p.vx = G.lerp(p.vx, Math.cos(a) * sp, .03); p.vy = G.lerp(p.vy, Math.sin(a) * sp * .5, .03); }
    p.x += p.vx * dt; p.y += p.vy * dt; if (p.x < 0 || p.x > w.W) return false;
    if (p.from === 'e') { if (Math.abs(p.x - P.x) < p.r + 8 && Math.abs(p.y - P.y) < 22 && Math.abs((p.z || 0) - 40 - P.z) < 60 + 0) { if (hurtPlayer(p.dmg, p) || P.blocking) { sparkle(p.x, p.y - 40, 8, p.k === 'orb' ? '#d07bff' : '#ccc'); return false; } } }
    else { for (const e of enemies) { if (e.dead) continue; if (Math.abs(e.x - p.x) < p.r + 22 && Math.abs(e.y - p.y) < 40) { hurtEnemy(e, p.dmg, Math.sign(p.vx) * 200, 0, { stun: .4 }); sparkle(p.x, p.y - 40, 14, '#ff9a3a'); A.sfx('hit'); return false; } } }
    if (p.k === 'fire' && Math.random() < .8) parts.push({ k: 'sp', x: p.x, y: p.y, z: p.z - 10, vx: G.rnd(-30, 30), vy: G.rnd(-30, 10), life: .4, max: .4, col: Math.random() < .5 ? '#ff8a1f' : '#ffd45e', r: G.rnd(3, 7), g: -40 });
    return true; });
}
function updateParts(dt) {
  parts = parts.filter(p => { p.life -= dt; if (p.life <= 0) return false; if (p.k === 'sp') { p.x += p.vx * dt; p.y += p.vy * dt * .5; p.z -= p.vy * dt * .5; p.vy += (p.g || 0) * dt; } return true; });
  floats = floats.filter(f => { f.life -= dt; f.y += f.vy * dt; return f.life > 0; });
  if (!G.settings.particles) return;
  const pt = w.def.parts, cnt = parts.filter(p => p.k === 'amb').length;
  if (pt && pt !== 'none' && cnt < 60 && !w.interior && Math.random() < .5) { const x = cam + Math.random() * 1280;
    if (pt === 'leaves') parts.push({ k: 'amb', t: 'leaf', x, y: -10, z: 0, vx: G.rnd(-20, 40), vy: G.rnd(50, 110), life: 9, max: 9, col: w.pal === 'autumn' ? G.pick(['#d9822b', '#e0a23a', '#c9622a']) : G.pick(['#3da34a', '#6fbf4a', '#9bc34a']), r: G.rnd(3, 5), ph: Math.random() * 6 });
    else if (pt === 'snow') parts.push({ k: 'amb', t: 'snow', x, y: -10, z: 0, vx: G.rnd(-30, 10), vy: G.rnd(60, 130), life: 8, max: 8, col: '#fff', r: G.rnd(1.5, 3.5), ph: Math.random() * 6 });
    else if (pt === 'fireflies') parts.push({ k: 'amb', t: 'ff', x, y: G.rnd(260, 640), z: 0, vx: G.rnd(-12, 12), vy: G.rnd(-8, 8), life: 8, max: 8, col: '#e8ff7a', r: 2.6, ph: Math.random() * 6 });
    else if (pt === 'dust') parts.push({ k: 'amb', t: 'dust', x, y: G.rnd(200, 700), z: 0, vx: G.rnd(-8, 20), vy: G.rnd(-5, 5), life: 8, max: 8, col: '#e6d6a8', r: 1.6, ph: Math.random() * 6 });
    else if (pt === 'fog') parts.push({ k: 'amb', t: 'fog', x, y: G.rnd(380, 700), z: 0, vx: G.rnd(8, 25), vy: 0, life: 14, max: 14, col: '#dfe9ef', r: G.rnd(90, 170), ph: 0 }); }
  parts.forEach(p => { if (p.k === 'amb') { p.x += p.vx * dt; p.y += p.vy * dt; p.ph += dt; if (p.t === 'leaf' || p.t === 'snow') p.x += Math.sin(p.ph * 2) * 30 * dt; if (p.t === 'ff') { p.x += Math.sin(p.ph * 1.5) * 20 * dt; p.y += Math.cos(p.ph * 1.2) * 20 * dt; } } });
}

/* ================== ATUALIZAÇÃO ================== */
function setMusicAuto() {
  const def = w.def; let want = def.music;
  if (w.interior) want = 'village';
  else if (boss && !boss.dead && boss.aggro) want = def.final ? 'final' : 'boss';
  else if (enemies.some(e => !e.dead && e.aggro && Math.hypot(e.x - P.x, e.y - P.y) < 420)) want = 'battle';
  if (want !== curMusic) { if (want === 'battle' || want === 'boss' || want === 'final') battleT = 4; if ((want === def.music || want === 'village') && battleT > 0) return; setMusic(want); }
  else if (battleT > 0 && (curMusic === 'battle')) { }
}
function update(dt) {
  T += dt; S.t += dt;
  if (IN.press.pause) { G.ui.pause(); }
  if (IN.press.inv) G.ui.inventory(); if (IN.press.map) G.ui.map(); if (IN.press.quest) G.ui.quests();
  if (G.ui.busy()) { IN.press = {}; return; }
  if (hitstop > 0) { hitstop -= dt; IN.press = {}; return; }
  updatePlayer(dt); updateCat(dt);
  enemies.forEach(e => { if (e.dead) { e.deadT -= dt; return; } enemyAI(e, dt); });
  enemies = enemies.filter(e => !e.dead || e.deadT > 0);
  updateProjs(dt); updateParts(dt);
  // coletáveis
  picks = picks.filter(pk => { pk.t += dt; if (Math.abs(pk.x - P.x) < 40 && Math.abs(pk.y - P.y) < 26) { S.picks[pk.key] = true; give(pk.it, 1); sparkle(pk.x, pk.y - 20, 10, '#ffe27a'); return false; } return true; });
  npcs.forEach(n => { n.t += dt; if (Math.abs(n.x - P.x) < 220) n.face = P.x > n.x ? 1 : -1; });
  // portas das casas
  w.houses.forEach(h => { const d = Math.hypot(h.x - P.x, (h.y - P.y) * 1.2); h.open = G.clamp(h.open + (d < 150 ? 1 : -1) * dt * 3, 0, 1); if (d < 150 && !h.snd) { h.snd = true; A.sfx('door'); } if (d >= 150) h.snd = false; });
  // câmera
  const target = w.interior ? 0 : G.clamp(P.x - 640 + P.face * 60, 0, w.W - 1280); cam = G.lerp(cam, target, 1 - Math.pow(.0008, dt));
  // regeneração / música / HUD
  shake = Math.max(0, shake - 40 * dt); flash = Math.max(0, flash - dt);
  if (battleT > 0) battleT -= dt; setMusicAuto();
  saveT += dt; if (saveT > 30) { saveT = 0; autosave(); }
  G.ui.hudTick(dt, { boss: boss && !boss.dead && boss.aggro ? boss : null, cd: P.cd, near: nearInteract(), obj: currentObjective() });
  IN.press = {};
}

/* ================== RENDER ================== */
function drawSpr(img, x, y, h, o = {}) {
  if (!img || !img.width) return; const r = img.width / img.height, ww = h * r;
  c.save(); c.translate(x, y); if (o.rot) c.rotate(o.rot); c.scale((o.flip ? -1 : 1) * (o.sx || 1), o.sy || 1);
  if (o.alpha !== undefined) c.globalAlpha = o.alpha; c.drawImage(img, -ww / 2, -h, ww, h);
  if (o.white) { c.globalAlpha = (o.alpha === undefined ? 1 : o.alpha) * o.white; c.drawImage(G.white(img), -ww / 2, -h, ww, h); }
  c.restore();
}
function shadow(x, y, rw, a = .35, z = 0) { if (!G.settings.shadows) return; const k = 1 - Math.min(.6, z / 200); c.fillStyle = `rgba(0,0,0,${a * k})`; c.beginPath(); c.ellipse(x, y, rw * k, rw * .28 * k, 0, 0, TAU); c.fill(); }
function enemyImg(e) { const d = e.d; let img = G.img[e.spr]; if (d.tint) img = G.variant(e.spr, d.tint); return img || G.img[e.spr]; }
function drawPlayer() {
  const sc = depth(P.y), h = 108 * sc, x = P.x, y = P.y - P.z, f = P.face < 0, bob = Math.sin(P.t * (P.st === 'run' ? 18 : 12)) * 2.5 * sc;
  shadow(P.x, P.y, 30 * sc, .4, P.z);
  let key = 'gnome_idle', o = { flip: f }, white = 0;
  const st = P.st;
  if (P.inv > 0 && Math.floor(T * 20) % 2 === 0 && st !== 'dodge' && !P.dead) o.alpha = .45;
  if (st === 'walk' || st === 'run') { key = Math.floor(P.t * (st === 'run' ? 11 : 7)) % 2 ? 'gnome_walk1' : 'gnome_walk2'; o.rot = Math.sin(P.t * (st === 'run' ? 14 : 9)) * (st === 'run' ? .1 : .05) + (st === 'run' ? .12 * P.face : 0); o.sy = 1 + Math.abs(Math.sin(P.t * 12)) * .03; }
  else if (st === 'jump') { key = 'gnome_cheer'; o.sy = 1 + Math.min(.12, Math.abs(P.vz) / 5000); o.sx = 1 - Math.min(.08, Math.abs(P.vz) / 7000); }
  else if (st === 'atk' || st === 'heavy') { key = 'gnome_sword'; const k = P.t / (st === 'atk' ? .3 : .55); o.rot = (st === 'heavy' ? (k < .5 ? -.25 * k * 2 : .35 * (k - .5) * 2) : .18 * Math.sin(k * Math.PI)) * P.face; o.sx = 1 + .08 * Math.sin(k * Math.PI); }
  else if (st === 'spin') { key = 'gnome_sword'; o.rot = P.t * 20; y -= 0; }
  else if (st === 'cast') { key = 'gnome_cheer'; o.sy = 1 + Math.sin(P.t * 12) * .03; }
  else if (st === 'def') { key = 'gnome_idle'; o.sy = .92; o.rot = -.06 * P.face; }
  else if (st === 'dodge') { key = 'gnome_walk1'; o.rot = P.t * 22 * P.face; o.alpha = .75; }
  else if (st === 'hurt') { key = 'gnome_talk'; o.rot = -.25 * P.face; white = .6; }
  else if (st === 'die') { key = 'gnome_talk'; o.rot = Math.min(1.57, P.t * 3) * -P.face; o.alpha = Math.max(.2, 1 - P.t * .4); }
  else if (st === 'cheer') { key = 'gnome_cheer'; P.z = 0; o.sy = 1 + Math.abs(Math.sin(P.t * 8)) * .06; }
  else if (st === 'talk') { key = 'gnome_talk'; }
  else { o.sy = 1 + Math.sin(P.t * 2.2) * .02; }
  if (flash > 0 && st === 'hurt') white = .8; if (white) o.white = white;
  const img = G.img[key]; let ux = x, uy = y + (st === 'walk' || st === 'run' ? -Math.abs(bob) : 0);
  if (st === 'spin') { c.save(); c.translate(ux, uy - h * .5); c.rotate(P.t * 20); drawSpr(img, 0, h * .5, h, { flip: f }); c.restore(); }
  else drawSpr(img, ux, uy, h, o);
  if ((st === 'atk' || st === 'heavy') && G.img.i_sword) { const k = Math.min(1, P.t / (st === 'atk' ? .3 : .55)), an = (-1.3 + 2.4 * k) * P.face, sz = 64 * sc; c.save(); c.translate(x + P.face * 22 * sc, uy - 46 * sc); c.rotate(an + (P.face < 0 ? -.8 : .8)); c.scale(P.face < 0 ? -1 : 1, 1); c.drawImage(G.img.i_sword, -sz * .1, -sz * .95, sz, sz); c.restore(); }
  if ((st === 'def' || P.blocking) && G.img.i_shield) { const sh = G.img.i_shield, sz = 54 * sc; c.drawImage(sh, x + P.face * 26 * sc - sz / 2, uy - 50 * sc - sz / 2, sz, sz); }
}
function blobS(x, y, r, col) { c.beginPath(); c.arc(x, y, r, 0, TAU); c.fillStyle = col; c.fill(); c.lineWidth = 3; c.strokeStyle = '#120c06'; c.stroke(); }
function drawSword(s, col, sheath) { c.lineJoin = 'round'; c.lineWidth = 3; c.strokeStyle = '#120c06';
  if (G.S.eq.weapon === 'sword_elf' || G.S.eq.weapon === 'sword_master') { c.shadowColor = col; c.shadowBlur = 14; }
  c.beginPath(); c.rect(-4 * s, -78 * s, 8 * s, 70 * s); c.fillStyle = sheath ? '#6b4a2a' : col; c.fill(); c.stroke(); c.shadowBlur = 0;
  c.beginPath(); c.rect(-12 * s, -10 * s, 24 * s, 6 * s); c.fillStyle = '#c9a24a'; c.fill(); c.stroke(); c.beginPath(); c.rect(-3.5 * s, -4 * s, 7 * s, 16 * s); c.fillStyle = '#6b4a2a'; c.fill(); c.stroke(); }
function drawCat() {
  if (!cat) return; const sc = depth(cat.y), h = 50 * sc; shadow(cat.x, cat.y, 20 * sc, .35, cat.z);
  let key = 'cat1', o = { flip: cat.face > 0 }; // sprite original olha para a esquerda
  if (cat.st === 'walk') key = Math.floor(cat.t * 6) % 2 ? 'cat1' : 'cat2'; else if (cat.st === 'run') { key = Math.floor(cat.t * 10) % 2 ? 'cat3' : 'cat2'; o.rot = .1 * cat.face; } else if (cat.st === 'leap' || cat.st === 'claw') { key = 'cat3'; o.rot = .3 * cat.face; } else o.sy = 1 + Math.sin(cat.t * 2.5) * .02;
  let img = G.img[key], hh = h * (key === 'cat3' ? 1.15 : 1);
  if (G.settings.catPix && G.img.c_idle && G.img.c_idle.width) { // gato preto em pixel-art (animação real, enviado pelo usuário)
    const n = cat.st === 'run' ? 'run' + (Math.floor(cat.t * 14) % 6) : cat.st === 'walk' ? 'walk' + (Math.floor(cat.t * 9) % 6) : (cat.st === 'leap' || cat.st === 'claw') ? 'run2' : 'idle';
    img = G.img['c_' + n]; hh = h * .95; o.rot = (cat.st === 'leap' || cat.st === 'claw') ? .25 * cat.face : 0; o.sy = 1; }
  drawSpr(img, cat.x, cat.y - cat.z, hh, o);
  if (cat.st === 'claw') { c.fillStyle = 'rgba(150,80,255,.35)'; c.beginPath(); c.arc(cat.x, cat.y - cat.z - 20, 30, 0, TAU); c.fill(); }
}
function drawEnemy(e) {
  const d = e.d, sc = depth(e.y), h = d.h * sc * (e.boss ? 1 : 1), x = e.x, y = e.y - e.z; const fl = e.flash > 0 || e.invuln > 0 && Math.floor(T * 14) % 2;
  shadow(e.x, e.y, Math.min(120, h * .3), .4, e.z);
  if (e.dead) { const k = 1 - e.deadT / .5; drawSpr(enemyImg(e), x, y, h, { flip: e.face > 0 === !!d.rev ? false : true, rot: k * 1.4 * (e.face || 1), alpha: 1 - k }); return; }
  const o = { flip: e.face > 0 }; // sprites originais olham para a esquerda
  if (d.alpha) o.alpha = d.alpha; if (e.alpha !== undefined) o.alpha = e.alpha; if (fl) o.white = .85;
  o.sy = 1 + Math.sin(e.t * (e.st === 'chase' ? 12 : 3)) * (e.st === 'chase' ? .04 : .015);
  if (e.st === 'wind') { o.sx = 1 - .1 * Math.sin(e.t * 30); o.rot = -.1 * (e.face); o.white = .25 + .25 * Math.sin(e.t * 40); }
  if (e.st === 'strike') o.rot = .25 * (e.face); if (e.hurt > 0) o.rot = -.2 * e.face;
  if (e.boss && (e.st === 'tele')) { o.sy = 1 + Math.sin(e.t * 20) * .04; o.white = .2 + .2 * Math.sin(e.t * 30); }
  if (e.boss && e.ptype === 'spin' && e.st === 'act') { c.save(); c.translate(x, y - h * .5); c.rotate(e.sp); drawSpr(enemyImg(e), 0, h * .5, h, o); c.restore(); }
  else {
    // ogro: corpo procedural sob o busto
    drawSpr(enemyImg(e), x, y, h, o);
  }
  // telegraph
  if (e.boss && e.st === 'tele') { if (e.ptype === 'slam') { c.globalAlpha = .25 + .15 * Math.sin(T * 20); c.fillStyle = '#ff2a2a'; c.beginPath(); c.ellipse(e.x, e.y, 170, 55, 0, 0, TAU); c.fill(); c.globalAlpha = 1; c.strokeStyle = '#ff5a5a'; c.lineWidth = 3; c.beginPath(); c.ellipse(e.x, e.y, 170, 55, 0, 0, TAU); c.stroke(); }
    if (e.ptype === 'charge') { c.strokeStyle = 'rgba(255,60,60,.6)'; c.lineWidth = 8; c.setLineDash([16, 10]); c.beginPath(); c.moveTo(e.x, e.y); c.lineTo(e.x + Math.cos(e.dir || 0) * 420, e.y + Math.sin(e.dir || 0) * 210); c.stroke(); c.setLineDash([]); } }
  if (e.st === 'wind' && !e.boss) { c.fillStyle = '#ff4a4a'; c.font = 'bold 26px sans-serif'; c.textAlign = 'center'; c.strokeStyle = '#000'; c.lineWidth = 4; c.strokeText('!', x, y - h - 6); c.fillText('!', x, y - h - 6); }
  if (!e.boss && e.hp < e.mhp) { const bw = 46; c.fillStyle = '#000a'; c.fillRect(x - bw / 2, y - h - 10, bw, 6); c.fillStyle = '#e24a3a'; c.fillRect(x - bw / 2 + 1, y - h - 9, (bw - 2) * e.hp / e.mhp, 4); }
}
function drawNpc(n) {
  const d = n.def, sc = depth(n.y), h = d.h * sc; shadow(n.x, n.y, 28 * sc, .35);
  let img = G.img[d.spr]; if (d.hue) { img = G.variant(d.spr, { hue: d.hue }); }
  const talking = G.ui.busy() && Math.abs(n.x - P.x) < 120; const o = { flip: n.face > 0 && true, sy: 1 + Math.sin(n.t * 2) * .015 }; if (d.spr === 'wizard') { o.flip = n.face > 0; }
  drawSpr(img, n.x, n.y, h, o);
  if (d.spr.startsWith('gnome') && d.hue) { // restaura rosto/barba (cores originais)
    const im = G.img[d.spr], r = im.width / im.height, ww = h * r; c.save(); c.translate(n.x, n.y); c.scale(o.flip ? -1 : 1, o.sy || 1); c.beginPath(); c.rect(-ww / 2, -h * .8, ww, h * .26); c.clip(); c.drawImage(im, -ww / 2, -h, ww, h); c.restore(); }
  const m = npcMarker(n); if (m) { const yy = n.y - h - 14 + Math.sin(T * 4) * 3; c.font = 'bold 34px sans-serif'; c.textAlign = 'center'; c.lineWidth = 5; c.strokeStyle = '#000'; c.strokeText(m, n.x, yy); c.fillStyle = m === '?' ? '#7dff8a' : '#ffd45e'; c.fillText(m, n.x, yy); }
  c.font = 'bold 12px Trebuchet MS'; c.textAlign = 'center'; c.fillStyle = '#fff'; c.lineWidth = 3; c.strokeStyle = '#000a'; c.strokeText(d.n, n.x, n.y + 16); c.fillText(d.n, n.x, n.y + 16);
}
function drawProjs() {
  projs.forEach(p => { const y = p.y - p.z;
    if (p.k === 'fire') { c.fillStyle = 'rgba(255,140,30,.35)'; c.beginPath(); c.arc(p.x, y, p.r * 1.8, 0, TAU); c.fill(); blobS(p.x, y, p.r, '#ff7a1a'); blobS(p.x, y, p.r * .5, '#ffe27a'); }
    else if (p.k === 'orb') { c.fillStyle = 'rgba(190,90,255,.35)'; c.beginPath(); c.arc(p.x, y, p.r * 1.7, 0, TAU); c.fill(); blobS(p.x, y, p.r * .8, '#b04aff'); blobS(p.x, y, p.r * .35, '#fff'); }
    else { c.save(); c.translate(p.x, y); c.rotate(p.ang || 0); c.strokeStyle = '#120c06'; c.lineWidth = 6; c.beginPath(); c.moveTo(-26, 0); c.lineTo(20, 0); c.stroke(); c.strokeStyle = '#a6713a'; c.lineWidth = 3; c.stroke(); c.fillStyle = '#c8ccd2'; c.beginPath(); c.moveTo(20, -7); c.lineTo(38, 0); c.lineTo(20, 7); c.fill(); c.restore(); }
    shadow(p.x, p.y, 10, .25); });
}
function drawParts(front) {
  parts.forEach(p => { const k = p.life / p.max;
    if (p.k === 'amb') { if (front !== (p.t !== 'fog')) return; return; }
    if (p.k === 'sp') { c.globalAlpha = Math.min(1, k * 1.4); c.fillStyle = p.col; c.beginPath(); c.arc(p.x, p.y - p.z, p.r * (.4 + k * .6), 0, TAU); c.fill(); c.globalAlpha = 1; }
    else if (p.k === 'ring') { c.strokeStyle = p.col || 'rgba(255,255,255,.8)'; c.globalAlpha = k; c.lineWidth = 6 * k + 1; c.beginPath(); c.ellipse(p.x, p.y, p.R * (1 - k * .6), p.R * (1 - k * .6) * .32, 0, 0, TAU); c.stroke(); c.globalAlpha = 1; }
    else if (p.k === 'slash') { c.save(); c.translate(p.x, p.y - p.z); c.scale(p.face, 1); c.globalAlpha = k; c.strokeStyle = p.col; c.lineWidth = p.big ? 14 : 9; c.lineCap = 'round'; c.beginPath(); c.arc(-30, 0, p.big ? 78 : 62, -1.0 - (1 - k) * .4, 1.0 + (1 - k) * .4); c.stroke(); c.strokeStyle = '#fff'; c.lineWidth = 3; c.stroke(); c.restore(); c.globalAlpha = 1; }
    else if (p.k === 'bolt') { c.strokeStyle = '#fff'; c.lineWidth = 6; c.shadowColor = '#7ad0ff'; c.shadowBlur = 20; c.globalAlpha = k; c.beginPath(); let bx = p.x, by = -10; c.moveTo(bx, by); while (by < p.y) { bx += G.rnd(-24, 24); by += 50; c.lineTo(bx, Math.min(by, p.y)); } c.stroke(); c.shadowBlur = 0; c.globalAlpha = 1; }
    else if (p.k === 'claw') { c.strokeStyle = '#c59bff'; c.globalAlpha = k; c.lineWidth = 5; for (let i = -1; i <= 1; i++) { c.beginPath(); c.moveTo(p.x - 30 + i * 12, p.y - p.z - 30); c.lineTo(p.x + 20 + i * 12, p.y - p.z + 20); c.stroke(); } c.globalAlpha = 1; }
  });
}
function drawAmb(frontOnly) {
  parts.forEach(p => { if (p.k !== 'amb') return; const k = Math.min(1, p.life / p.max * 2, (p.max - p.life) * 2) ;
    const sx = p.x - cam * (p.t === 'fog' ? 1 : 1);
    if (p.t === 'leaf') { c.save(); c.translate(sx, p.y); c.rotate(p.ph * 3); c.fillStyle = p.col; c.beginPath(); c.ellipse(0, 0, p.r * 1.8, p.r, 0, 0, TAU); c.fill(); c.restore(); }
    else if (p.t === 'snow' || p.t === 'dust') { c.globalAlpha = .8 * k; c.fillStyle = p.col; c.beginPath(); c.arc(sx, p.y, p.r, 0, TAU); c.fill(); c.globalAlpha = 1; }
    else if (p.t === 'ff') { const g = .5 + .5 * Math.sin(p.ph * 4); c.globalAlpha = k * g; c.fillStyle = p.col; c.shadowColor = '#e8ff7a'; c.shadowBlur = 12; c.beginPath(); c.arc(sx, p.y, p.r, 0, TAU); c.fill(); c.shadowBlur = 0; c.globalAlpha = 1; }
    else if (p.t === 'fog') { const gr = c.createRadialGradient(sx, p.y, 0, sx, p.y, p.r); gr.addColorStop(0, `rgba(223,233,239,${.18 * k})`); gr.addColorStop(1, 'rgba(223,233,239,0)'); c.fillStyle = gr; c.fillRect(sx - p.r, p.y - p.r, p.r * 2, p.r * 2); }
  });
}
function drawBG() {
  const bgk = 'bg_' + w.def.bg, img = G.img[bgk]; P2.bgKey = w.def.bg;
  if (w.interior) { c.drawImage(img, 0, 0, 1280, 720); return; }
  // espelha para dobrar a largura, com paralaxe suave
  const par = 1, off = -cam * par, W2 = 1280;
  for (let i = 0; i * W2 < w.W + W2; i++) { const x = off + i * W2; if (x > 1280 || x + W2 < 0) continue; c.save(); if (i % 2) { c.translate(x + W2, 0); c.scale(-1, 1); c.drawImage(img, 0, 0, W2, 720); } else c.drawImage(img, x, 0, W2, 720); c.restore(); }
}
const OUT_ = '#120c06';
function drawTrail() {
  const def = w.def, bi = def.bi; const col = bi === 'snow' || bi === 'summit' ? [225, 238, 248] : bi === 'cave' || bi === 'dungeon' || bi === 'castle' || bi === 'temple' || bi === 'ruins' ? [90, 90, 100] : bi === 'canyon' ? [190, 110, 70] : bi === 'water' ? [170, 150, 110] : bi === 'swamp' ? [70, 60, 40] : [140, 105, 62];
  c.beginPath(); const x0 = Math.floor(cam / 40) * 40 - 40, x1 = cam + 1320;
  for (let x = x0; x <= x1; x += 40) { const p = w.path(x), sx = x - cam; x === x0 ? c.moveTo(sx, p.yt) : c.lineTo(sx, p.yt); }
  for (let x = x1; x >= x0; x -= 40) { const p = w.path(x), sx = x - cam; c.lineTo(sx, p.yb); }
  c.closePath(); const g = c.createLinearGradient(0, w.gy[0], 0, 720); g.addColorStop(0, `rgba(${col},.30)`); g.addColorStop(1, `rgba(${col},.62)`); c.fillStyle = g; c.fill();
  c.lineWidth = 3; c.strokeStyle = `rgba(${col.map(v => v * .5 | 0)},.55)`; c.stroke();
}
function render() {
  c.save(); if (shake > 0) c.translate(G.rnd(-shake, shake) * .5, G.rnd(-shake, shake) * .5);
  drawBG();
  c.save(); c.translate(-cam, 0);
  // água/ponte (abaixo das entidades)
  if (w.water) { const wt = w.water; P2.bridge(c, wt.x, wt.w, w.bridgeY, w.bridgeHW, w.def.id !== 'rio' || S.flags.bridge); }
  // lista y-ordenada
  const L = [];
  if (!w.interior) {
    w.deco.forEach(o => { if (o.x > cam - 140 && o.x < cam + 1420) L.push({ y: o.y, f: () => P2.drawProp(c, o, T, w.def.bi) }); });
    w.obs.forEach(o => { if (o.draw && o.x > cam - 140 && o.x < cam + 1420) L.push({ y: o.y + 2, f: () => { shadowBase(o); P2.drawProp(c, o, T, w.def.bi); } }); });
    w.houses.forEach(h => L.push({ y: h.y - 100, f: () => P2.house(c, h, T, h.open) }));
    w.camps.forEach(t => L.push({ y: t.y, f: () => P2.campfire(c, t.x, t.y, T) }));
  } else { w.furn.forEach(f => L.push({ y: f.y - (f.k === 'rug' ? 999 : 0), f: () => P2.furn(c, f.k, f.x, f.y, T) })); }
  chests.forEach(ch => { if (!w.interior || !ch.fixed) L.push({ y: ch.y, f: () => P2.chest(c, ch.x, ch.y, ch.open, T, true) }); else L.push({ y: ch.y + 1, f: () => { if (ch.open) { P2.chest(c, ch.x, ch.y, true, T, false); } } }); });
  picks.forEach(pk => L.push({ y: pk.y, f: () => drawPick(pk) }));
  npcs.forEach(n => L.push({ y: n.y, f: () => drawNpc(n) }));
  enemies.forEach(e => L.push({ y: e.y, f: () => drawEnemy(e) }));
  L.push({ y: cat.y, f: drawCat }); L.push({ y: P.y + .1, f: drawPlayer });
  L.sort((a, b) => a.y - b.y).forEach(o => o.f());
  drawProjs(); drawParts();
  if (!w.interior) w.fg.forEach(o => { if (o.x > cam - 120 && o.x < cam + 1400) P2.drawProp(c, o, T, w.def.bi); });
  floats.forEach(f => { c.globalAlpha = Math.min(1, f.life * 2); c.font = 'bold 22px Trebuchet MS'; c.textAlign = 'center'; c.lineWidth = 4; c.strokeStyle = '#000'; c.strokeText(f.t, f.x, f.y); c.fillStyle = f.col; c.fillText(f.t, f.x, f.y); c.globalAlpha = 1; });
  c.restore();
  drawAmb();
  // exits hint
  if (!w.interior) { drawExitHint(); }
  lighting();
  if (flash > 0) { c.fillStyle = `rgba(255,${P && P.dead ? 0 : 60},${P && P.dead ? 0 : 60},${flash * .5})`; c.fillRect(0, 0, 1280, 720); }
  if (S.hp < stats().maxhp * .25 && !P.dead) { c.fillStyle = `rgba(160,0,0,${.12 + .08 * Math.sin(T * 6)})`; c.fillRect(0, 0, 1280, 720); }
  c.restore();
}
function shadowBase(o) { if (o.k === 'tree' || o.k === 'pine' || o.k === 'rock' || o.k === 'bush') shadow(o.x, o.y, o.rx * 1.3, .3); }
function drawPick(pk) { const y = pk.y + Math.sin(pk.t * 3) * 3, im = G.itemImg(pk.it); if (im && im.width) { const sz = 40; c.drawImage(im, pk.x - sz / 2, y - sz - 2, sz, sz); } else P2.drawTex(c, 'flowers', pk.x, y, 36); }
function drawExitHint() {
  const def = w.def; if (P.x > w.W - 380 && def.i < G.AREAS.length - 1) { const a = .5 + .5 * Math.sin(T * 4); c.globalAlpha = a; c.fillStyle = '#ffd45e'; c.font = 'bold 40px sans-serif'; c.textAlign = 'right'; c.fillText('▶', 1264, w.path(w.W - 40).cy); c.globalAlpha = 1; }
}
let lightC = null, lx = null;
function lighting() {
  const def = w.def, tn = def.tint; if (tn && !w.interior) { c.fillStyle = `rgba(${tn[0]},${tn[1]},${tn[2]},${tn[3]})`; c.fillRect(0, 0, 1280, 720); }
  let dark = w.interior ? .18 : (def.dark || 0); if (!G.settings.light) dark = Math.min(dark, .12);
  if (dark <= 0) return;
  if (!lightC) { lightC = document.createElement('canvas'); lightC.width = 1280; lightC.height = 720; lx = lightC.getContext('2d'); }
  lx.globalCompositeOperation = 'source-over'; lx.clearRect(0, 0, 1280, 720); const tt = def.tint || [0, 0, 20, 0];
  lx.fillStyle = w.interior ? `rgba(30,12,0,${dark})` : `rgba(${tt[0] * .3 | 0},${tt[1] * .3 | 0},${tt[2] * .4 + 10 | 0},${Math.min(.88, dark + .18)})`; lx.fillRect(0, 0, 1280, 720);
  lx.globalCompositeOperation = 'destination-out';
  const L = (x, y, r, a = 1) => { const sx = x - (w.interior ? 0 : cam), g = lx.createRadialGradient(sx, y, r * .1, sx, y, r); g.addColorStop(0, `rgba(0,0,0,${a})`); g.addColorStop(1, 'rgba(0,0,0,0)'); lx.fillStyle = g; lx.fillRect(sx - r, y - r, r * 2, r * 2); };
  L(P.x, P.y - 50, 280 + (S.hp < 30 ? 0 : 0)); L(cat.x, cat.y - 20, 90, .6);
  w.camps.forEach(t => L(t.x, t.y - 20, 330 + Math.sin(T * 8) * 14)); projs.forEach(p => { if (p.k === 'fire' || p.k === 'orb') L(p.x, p.y - p.z, 150); });
  if (w.interior) w.furn.filter(f => f.k === 'fire').forEach(f => L(f.x, f.y - 50, 420)); if (w.interior) { L(640, 500, 520, .9); }
  if (boss && !boss.dead && boss.d.void) L(boss.x, boss.y - 120, 180, .6);
  c.drawImage(lightC, 0, 0);
  // vinheta
  const g = c.createRadialGradient(640, 360, 300, 640, 360, 860); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${.25 + dark * .3})`); c.fillStyle = g; c.fillRect(0, 0, 1280, 720);
}

/* ================== SAVE ================== */
function snapshot() { return JSON.stringify({ S, v: 1, px: P ? P.x : S.x, py: P ? P.y : S.y }); }
function saveGame() { try { const s = Object.assign({}, S); if (!S.int && P) { s.x = P.x; s.y = P.y; } localStorage.setItem('gnomo_save_v1', JSON.stringify({ S: s, v: 1, at: Date.now() })); } catch (e) {} }
function autosave() { saveGame(); const e = document.getElementById('toast'); }
G.saveGame = saveGame;
G.newGame = () => { S = newState(); G.S = S; };
G.loadGame = () => { const d = G.save(); if (!d || !d.S) return false; S = Object.assign(newState(), d.S); G.S = S; return true; };

/* ================== CONTROLE DE FLUXO ================== */
G.start = function (fromSave) {
  mode = 'play'; A.init(); document.getElementById('hud').classList.remove('hidden');
  const st = stats(); if (fromSave) { const a = S.area; S.int = null; enterArea(a, { x: S.x, y: S.y }, false); P.y = w.path(P.x).cy; S.hp = Math.max(S.hp, 1); }
  else { S.hp = st.maxhp; S.en = st.maxen; enterArea('floresta', { x: 300, y: 570 }); toast('Fale com o Mestre Azul (tecla E) à direita.', 5000); }
  G.ui.hud();
};
G.respawn = function () { const st = stats(); S.hp = st.maxhp; S.en = st.maxen; S.coins = Math.floor(S.coins * .9); const a = S.area, def = G.AMAP[a] || G.AMAP[S.ret ? S.ret.area : 'floresta']; fadeTo(() => { enterArea(def.id, 'L'); toast('Você acordou no início da área.'); }); };
G.cheer = () => { if (P) { P.st = 'cheer'; P.t = 0; setTimeout(() => { if (P && P.st === 'cheer') P.st = 'idle'; }, 1500); } };
G.setTalk = on => { if (P && !P.dead) { if (on) { P.st = 'talk'; } else if (P.st === 'talk') P.st = 'idle'; } };
G.mode = m => { if (m) mode = m; return mode; };
G.renderMenuBG = function (key, t) { // fundo animado do menu / cinemática
  const img = G.img['bg_' + key]; if (!img) return; const z = 1.05 + .05 * Math.sin(t * .2), ox = Math.sin(t * .15) * 30;
  c.save(); c.fillStyle = '#000'; c.fillRect(0, 0, 1280, 720); c.translate(640 + ox, 360); c.scale(z, z); c.drawImage(img, -640, -360, 1280, 720); c.restore();
};
G.cineChars = function (t) { const a = [['wizard', 0, 1], ['gnome_idle', 1, 1], ['cat1', 2, 1]]; };
let last = 0, menuT = 0;
function frame(ts) {
  const dt = Math.min(.05, (ts - last) / 1000 || .016); last = ts;
  try {
    if (mode === 'play' && S && w) { update(dt); render(); }
    else if (mode === 'menu' || mode === 'cine') { menuT += dt; G.ui.menuDraw(c, dt, menuT); }
    else if (mode === 'ending' && w) { T += dt; render(); }
  } catch (e) { console.error(e); G.lastError = e; }
  requestAnimationFrame(frame);
}
G.boot = function () { G.loadAll(p => G.ui.loading(p)).then(() => { mode = 'menu'; G.ui.mainMenu(); requestAnimationFrame(frame); }); };
G.draw = { spr: drawSpr, c, blobS };
G.debug = () => ({ S, w, P, enemies, cat, npcs, boss });
G.enterArea = enterArea;
})();
