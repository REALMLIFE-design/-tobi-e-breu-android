/* ui.js — menus, HUD, diálogos, inventário, loja, mapa, missões, controles de toque, cinemáticas */
(function () {
const $ = id => document.getElementById(id), A = G.audio;
const panel = $('panel'); let panelOpen = false, dlg = null, cine = null, hudT = 0, isTouch = false;
const ui = G.ui = {};
const esc = s => String(s).replace(/[&<>]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[m]));
ui.busy = () => panelOpen || !!dlg || !!cine;
function show(html, cls = '') { panel.innerHTML = '<div class="pn ' + cls + '">' + html + '</div>'; panel.classList.remove('hidden'); panelOpen = true; panel.scrollTop = 0; }
function close() { panel.classList.add('hidden'); panel.innerHTML = ''; panelOpen = false; }
ui.close = close;
const on = (id, fn) => { const e = $(id); if (e) e.onclick = () => { A.sfx('ui'); fn(); }; };
function applyTouch() { const s = G.settings.touch; isTouch = s === 'on' || (s === 'auto' && ('ontouchstart' in window || navigator.maxTouchPoints > 0)); if (G.mode() === 'play') $('touch').classList.toggle('hidden', !isTouch); }

/* ---------- carregamento / menu ---------- */
ui.loading = p => show('<div class="menu"><h1>Tobi e Breu</h1><p>Carregando… ' + Math.round(p * 100) + '%</p></div>');
ui.mainMenu = function () {
  G.mode('menu'); $('hud').classList.add('hidden'); $('touch').classList.add('hidden'); $('cine').classList.add('hidden');
  const has = !!G.save();
  show('<div class="menu main-menu"><div class="menu-mark">✦ UMA AVENTURA ENTRE RAÍZES E SOMBRAS ✦</div>' +
    '<h1><span>TOBI</span> <i>&</i> <span>BREU</span></h1><div class="menu-subtitle">A LENDA DO PEQUENO GUARDIÃO</div>' +
    '<p class="menu-lore">Quando a floresta antiga chamou por ajuda, um pequeno gnomo e seu companheiro partiram para enfrentar a escuridão.</p>' +
    '<div class="menu-actions">' + (has ? '<button class="mbtn primary" id="m-cont"><span>▶</span> CONTINUAR JORNADA</button>' : '') +
    '<button class="mbtn primary" id="m-new"><span>⚔</span> NOVA AVENTURA</button>' +
    '<div class="menu-secondary"><button class="mbtn" id="m-set">⚙ Opções</button><button class="mbtn" id="m-ctl">⌘ Controles</button><button class="mbtn" id="m-cred">✧ Créditos</button></div></div>' +
    '<div class="menu-foot">RPG DE AVENTURA · 2.5D <b>•</b> PORTUGUÊS (BRASIL)</div></div>');
  on('m-cont', () => { A.init(); A.music('forest'); if (G.loadGame()) { close(); applyTouch(); G.start(true); } });
  on('m-new', () => { A.init(); if (has && !confirm('Isso apagará o progresso salvo. Continuar?')) return; close(); G.newGame(); playCine(G.INTRO, () => { G.mode('play'); applyTouch(); G.start(false); }, 'menu'); });
  on('m-set', () => ui.settings(ui.mainMenu)); on('m-ctl', () => ui.controls(ui.mainMenu)); on('m-cred', () => ui.credits(ui.mainMenu));
  A.init(); A.music('menu');
};
ui.controls = function (back) {
  show('<h2>Controles</h2><div class="row"><div class="card" style="flex:1"><b>Computador</b><br>WASD / Setas: mover · Shift: correr<br>Espaço: pular · J ou clique: atacar<br>K: golpe forte · L: esquiva · F (ou botão direito): defender<br>E: interagir · 1-4: habilidades · C: Garra do Breu<br>I: inventário · Q: missões · M: mapa · Esc: pausa</div>' +
    '<div class="card" style="flex:1"><b>Celular</b><br>Joystick: mover (empurre até a borda para correr)<br>⚔ atacar · 💨 esquiva · ⤒ pular · 🛡 defender (segure)<br>✋ interagir · ✨ habilidades (1-4 e 🐈)</div></div><button id="bk">Voltar</button>'); on('bk', back);
};
ui.credits = function (back) { show('<h2>Créditos</h2><div class="credits">' + esc(G.CREDITS) + '</div><button id="bk">Voltar</button>'); on('bk', back); };
ui.settings = function (back) {
  const s = G.settings;
  show('<h2>Configurações</h2><div class="row">Música <input type="range" id="s-m" min="0" max="1" step=".05" value="' + s.music + '"></div><div class="row">Efeitos <input type="range" id="s-e" min="0" max="1" step=".05" value="' + s.sfx + '"></div>' +
    '<div class="row"><label><input type="checkbox" id="s-p" ' + (s.particles ? 'checked' : '') + '> Partículas</label> <label><input type="checkbox" id="s-s" ' + (s.shadows ? 'checked' : '') + '> Sombras</label> <label><input type="checkbox" id="s-l" ' + (s.light ? 'checked' : '') + '> Iluminação dinâmica</label></div>' +
    '<div class="row">Controles de toque <select id="s-t"><option value="auto">Automático</option><option value="on">Sempre</option><option value="off">Nunca</option></select></div><div class="row">Transparência do HUD <input type="range" id="s-ho" min=".2" max="1" step=".05" value="' + s.hudO + '"></div><div class="row">Transparência dos botões <input type="range" id="s-to" min=".2" max="1" step=".05" value="' + s.touO + '"></div><div class="row">Tamanho dos botões <input type="range" id="s-ts" min=".6" max="1.5" step=".05" value="' + s.touS + '"></div><div class="row"><button id="s-mv">✥ Mover botões na tela</button><button id="s-rs">↺ Restaurar posições</button></div><div class="row"><label><input type="checkbox" id="s-cp" ' + (s.catPix ? 'checked' : '') + '> Gato em pixel-art animado (pacote enviado)</label></div><div class="row">Idioma <select id="s-g"><option>Português (Brasil)</option></select></div><button id="bk">Voltar</button>');
  $('s-t').value = s.touch; const upd = () => { s.music = +$('s-m').value; s.sfx = +$('s-e').value; s.particles = $('s-p').checked; s.shadows = $('s-s').checked; s.light = $('s-l').checked; s.touch = $('s-t').value; s.catPix = $('s-cp').checked; s.hudO = +$('s-ho').value; s.touO = +$('s-to').value; s.touS = +$('s-ts').value; G.applyHud(); G.saveSettings(); A.vol(); applyTouch(); };
  ['s-m', 's-e', 's-p', 's-s', 's-l', 's-t', 's-cp', 's-ho', 's-to', 's-ts'].forEach(i => $(i).onchange = $(i).oninput = upd); on('bk', back);
  on('s-rs', () => { s.jx = s.jy = s.bx = s.by = 0; G.applyHud(); G.saveSettings(); });
  on('s-mv', () => ui.editHud(() => ui.settings(back)));
};

/* ---------- cinemática ---------- */
function playCine(list, done, ret) {
  cine = { list, i: 0, t: 0, ch: 0, done }; G.mode('cine'); $('cine').classList.remove('hidden'); $('hud').classList.add('hidden'); A.music('menu');
  $('cine-skip').onclick = () => { A.sfx('ui'); endCine(); };
}
function endCine() { if (!cine) return; const d = cine.done; cine = null; $('cine').classList.add('hidden'); $('cine-t').textContent = ''; d && d(); }
ui.menuDraw = function (c, dt, t) {
  if (cine) { const s = cine.list[cine.i]; cine.t += dt; cine.ch += dt * 38;
    G.renderMenuBG(s.bg, cine.t + cine.i * 3);
    // personagens em cena
    const f = Math.min(1, cine.t / 1.5); [['wizard', 300, 150], ['gnome_idle', 640, 108], ['cat1', 800, 52]].forEach(([k, x, h], j) => { if (cine.i === 0 && j === 0) return; G.draw.spr(G.img[k], x + (1 - f) * -60 + Math.sin(cine.t * 2 + j) * 3, 560, h * 1.5, { flip: j === 2 }); });
    c.fillStyle = 'rgba(0,0,0,.45)'; c.fillRect(0, 0, 1280, 720); c.fillStyle = '#000'; c.fillRect(0, 0, 1280, 60); c.fillRect(0, 660, 1280, 60);
    $('cine-t').textContent = s.t.slice(0, Math.floor(cine.ch)); if (cine.t > Math.max(5, s.t.length * .075)) { cine.i++; cine.t = 0; cine.ch = 0; if (cine.i >= cine.list.length) endCine(); }
    return; }
  G.renderMenuBG('forest_meadow', t); c.fillStyle = 'rgba(0,0,0,.35)'; c.fillRect(0, 0, 1280, 720);
  const x = (t * 60) % 1500 - 100; [['wizard', x + 160, 170], ['gnome_idle', x, 120], ['cat1', x - 90, 56]].forEach(([k, px, h], j) => { const kk = j === 1 ? (Math.floor(t * 4) % 2 ? 'gnome_walk1' : 'gnome_walk2') : k; G.draw.spr(G.img[kk], px, 640 + Math.sin(t * 8 + j) * 2, h * 1.5, { flip: j !== 2 ? true : true }); });
};

/* ---------- HUD ---------- */
ui.hud = function () {
  const S = G.S; if (!S) return; const st = G.stats(), need = G.xpNeed(S.lvl);
  $('hpf').style.transform = 'scaleX(' + G.clamp(S.hp / st.maxhp, 0, 1) + ')'; $('enf').style.transform = 'scaleX(' + G.clamp(S.en / st.maxen, 0, 1) + ')'; $('xpf').style.transform = 'scaleX(' + G.clamp(S.xp / need, 0, 1) + ')';
  $('hpt').textContent = Math.ceil(S.hp) + ' / ' + st.maxhp; $('ent').textContent = Math.floor(S.en) + ' / ' + st.maxen; $('xpt').textContent = S.xp + '/' + need;
  $('lvl').textContent = 'Nv ' + S.lvl; $('coins').textContent = S.coins;
  const keys = ['1', '2', '3', '4', 'c'], ids = ['spin', 'fire', 'heal', 'thunder', 'claw'];
  if (!$('skills').children.length) { $('skills').innerHTML = ids.map((id, i) => '<div class="sk" data-k="' + keys[i] + '"><small>' + keys[i].toUpperCase() + '</small>' + '<img src="' + G.SKICON[id] + '"><div class="cd"></div></div>').join(''); [...$('skills').children].forEach((e, i) => e.onclick = () => G.press('sk' + (i < 4 ? i + 1 : 'c'))); $('skills').style.pointerEvents = 'auto'; }
  [...$('skills').children].forEach((e, i) => e.classList.toggle('lock', !S.skills[ids[i]]));
  const o = G.currentObjective(); $('hud-qt').textContent = o ? o.txt : 'Explore o mundo!';
};
ui.hudTick = function (dt, info) {
  hudT += dt; const S = G.S; if (hudT > .15) { hudT = 0; ui.hud(); }
  const b = info.boss; $('boss').classList.toggle('hidden', !b); if (b) { $('boss-name').textContent = b.d.n + ' — ' + (b.d.title || ''); $('bossf').style.transform = 'scaleX(' + G.clamp(b.hp / b.mhp, 0, 1) + ')'; }
  const ids = ['sk1', 'sk2', 'sk3', 'sk4', 'skc'], ks = [1, 2, 3, 4, 'c'], sd = ['spin', 'fire', 'heal', 'thunder', 'claw'];
  [...$('skills').children].forEach((e, i) => { const cd = info.cd[ks[i]] || 0, mx = G.SKILLS[sd[i]].cd; e.lastChild.style.height = (cd / mx * 100) + '%'; });
  const p = $('prompt'); if (info.near && !ui.busy()) { p.textContent = (isTouch ? '✋ ' : 'E: ') + info.near.label; p.classList.remove('hidden'); } else p.classList.add('hidden');
};

/* ---------- diálogos ---------- */
ui.say = function (name, lines, spr, cb, hue) {
  if (dlg) return; dlg = { lines: lines.slice(), i: 0, ch: 0, cb, name, spr, hue }; $('dlg').classList.remove('hidden'); $('dlgn').textContent = name; G.setTalk(true); A.sfx('ui');
  const pc = $('dlgp').getContext('2d'); pc.clearRect(0, 0, 120, 120); const img = hue ? G.variant(spr, { hue }) : G.img[spr];
  if (img && img.width) { const r = img.width / img.height; let h = 112, w = h * r; if (w > 112) { w = 112; h = w / r; } pc.drawImage(img, (120 - w) / 2, 116 - h, w, h); }
  dlg.timer = setInterval(() => { if (!dlg) return; dlg.ch += 2; $('dlgt').textContent = dlg.lines[dlg.i].slice(0, dlg.ch); }, 25);
};
function advance() {
  if (!dlg) return; const full = dlg.lines[dlg.i];
  if (dlg.ch < full.length) { dlg.ch = full.length; $('dlgt').textContent = full; return; }
  dlg.i++; dlg.ch = 0; if (dlg.i >= dlg.lines.length) { const cb = dlg.cb; clearInterval(dlg.timer); dlg = null; $('dlg').classList.add('hidden'); G.setTalk(false); cb && setTimeout(cb, 30); }
  else $('dlgt').textContent = '';
}
$('dlg').onclick = advance;
addEventListener('keydown', e => { if (dlg && (e.code === 'KeyE' || e.code === 'Enter' || e.code === 'Space')) { advance(); e.preventDefault(); } if (cine && e.code === 'Escape') endCine(); });

/* ---------- painéis do jogo ---------- */
function toggle(name, fn) { if (panelOpen && panel.dataset.n === name) { close(); panel.dataset.n = ''; return; } if (panelOpen || dlg || cine) return; fn(); panel.dataset.n = name; }
ui.pause = function () {
  if (panelOpen && panel.dataset.n === 'pause') { close(); panel.dataset.n = ''; return; } if (panelOpen) { close(); panel.dataset.n = ''; return; } if (dlg || cine || G.mode() !== 'play') return;
  show('<div class="menu"><h2>Pausa</h2><button class="mbtn" id="p-r">▶ Continuar</button><button class="mbtn" id="p-i">🎒 Inventário</button><button class="mbtn" id="p-q">📜 Missões</button><button class="mbtn" id="p-m">🗺 Mapa</button><button class="mbtn" id="p-s">💾 Salvar</button><button class="mbtn" id="p-o">⚙ Configurações</button><button class="mbtn" id="p-c">🎮 Controles</button><button class="mbtn" id="p-x">⌂ Menu principal</button></div>');
  panel.dataset.n = 'pause'; on('p-r', () => { close(); panel.dataset.n = ''; }); on('p-i', ui.inventory); on('p-q', ui.quests); on('p-m', ui.map); on('p-s', () => { G.saveGame(); G.toast('Jogo salvo 💾'); });
  on('p-o', () => ui.settings(ui.pause)); on('p-c', () => ui.controls(ui.pause)); on('p-x', () => { G.saveGame(); close(); panel.dataset.n = ''; G.mode('menu'); ui.mainMenu(); });
};
let invTab = 'items';
ui.inventory = function () {
  toggle('inv', () => draw()); if (panel.dataset.n === 'pause' || !panelOpen) { } function draw() { render(); }
  function render() { const S = G.S, I = G.ITEMS, st = G.stats(); panel.dataset.n = 'inv';
    const tabs = [['items', '🎒 Itens'], ['equip', '🛡 Equipamento'], ['skills', '✨ Habilidades']].map(([k, n]) => '<button data-t="' + k + '" class="' + (invTab === k ? 'on' : '') + '">' + n + '</button>').join('');
    let body = '';
    if (invTab === 'items') { const ids = Object.keys(S.inv); body = '<div class="grid">' + (ids.length ? ids.map(id => { const it = I[id]; return '<div class="card"><b>' + G.ico(id) + ' ' + it.n + '</b> ×' + S.inv[id] + '<br><small>' + it.d + '</small><br>' + (it.t === 'use' ? '<button data-u="' + id + '">Usar</button>' : (['weapon', 'armor', 'amulet'].includes(it.t) ? '<button data-e="' + id + '">' + (S.eq.weapon === id || S.eq.armor === id || S.eq.amulet === id ? 'Equipado' : 'Equipar') + '</button>' : '')) + '</div>'; }).join('') : '<p>Vazio.</p>') + '</div>'; }
    else if (invTab === 'equip') { const e = S.eq; body = '<div class="row"><div class="card"><b>Arma</b><br>' + G.ico(e.weapon) + ' ' + I[e.weapon].n + ' (+' + I[e.weapon].atk + ' atk)</div><div class="card"><b>Armadura</b><br>' + G.ico(e.armor) + ' ' + I[e.armor].n + ' (+' + I[e.armor].def + ' def)</div><div class="card"><b>Amuleto</b><br>' + (e.amulet ? G.ico(e.amulet) + ' ' + I[e.amulet].n : '—') + '</div></div>' +
      '<div class="card">Nível ' + S.lvl + ' · Vida máx ' + st.maxhp + ' · Energia máx ' + st.maxen + '<br>Ataque ' + st.atk.toFixed(1) + ' · Defesa ' + st.def.toFixed(1) + ' · Dano do Breu ×' + st.cat.toFixed(2) + '<br>Inimigos derrotados: ' + S.kills + ' · Tempo: ' + Math.floor(S.t / 60) + ' min</div><h3>Equipáveis</h3><div class="grid">' + Object.keys(S.inv).filter(id => ['weapon', 'armor', 'amulet'].includes(I[id].t)).map(id => '<div class="card"><b>' + G.ico(id) + ' ' + I[id].n + '</b><br><small>' + I[id].d + '</small><br><button data-e="' + id + '">Equipar</button></div>').join('') + '</div>'; }
    else body = '<div class="grid">' + Object.keys(G.SKILLS).map(id => { const s = G.SKILLS[id], has = S.skills[id]; return '<div class="card" style="opacity:' + (has ? 1 : .45) + '"><b><img class="ico" src="' + G.SKICON[id] + '"> ' + s.n + '</b> [' + s.key + ']<br><small>' + s.d + '</small><br>Custo: ' + s.cost + ' EN · Recarga: ' + s.cd + 's' + (has ? '' : '<br><i>Bloqueada</i>') + '</div>'; }).join('') + '</div>';
    show('<h2>Inventário · ' + G.COIN + ' ' + S.coins + '</h2><div class="tabs">' + tabs + '</div>' + body + '<br><button id="bk">Fechar</button>'); panel.dataset.n = 'inv';
    panel.querySelectorAll('[data-t]').forEach(b => b.onclick = () => { invTab = b.dataset.t; A.sfx('ui'); render(); }); panel.querySelectorAll('[data-u]').forEach(b => b.onclick = () => { G.useItem(b.dataset.u); render(); }); panel.querySelectorAll('[data-e]').forEach(b => b.onclick = () => { G.equip(b.dataset.e); render(); });
    on('bk', () => { close(); panel.dataset.n = ''; }); }
  if (panelOpen && panel.dataset.n !== 'inv' && G.mode() === 'play') render();
};
ui.quests = function () {
  const draw = () => { const S = G.S, q = G.QUESTS; const row = (x, k) => { const st = S.quests[x.id]; const objs = x.obj.map((o, i) => { const p = G.quest.prog(x, i), n = o.n || 1; return '<li>' + (p >= n ? '✔ ' : '◻ ') + o.txt + (n > 1 ? ' (' + p + '/' + n + ')' : '') + '</li>'; }).join(''); return '<div class="card ' + (st.st === 'ready' ? 'sel' : '') + '"><b>' + x.t + '</b> ' + (st.st === 'ready' ? '— <i>entregar a ' + G.NPC[x.giver].n + '</i>' : '') + '<ul style="margin:4px 0 0 16px;padding:0">' + objs + '</ul></div>'; };
    const act = q.filter(x => S.quests[x.id] && S.quests[x.id].st !== 'done'), done = q.filter(x => S.quests[x.id] && S.quests[x.id].st === 'done');
    show('<h2>Missões</h2><p>Concluídas: ' + done.length + ' / ' + q.length + '</p><h3>Ativas</h3>' + (act.map(x => row(x)).join('') || '<p>Nenhuma. Converse com os habitantes!</p>') + '<h3>Concluídas</h3><div class="grid">' + done.map(x => '<div class="card">✔ ' + x.t + '</div>').join('') + '</div><br><button id="bk">Fechar</button>'); panel.dataset.n = 'quest'; on('bk', () => { close(); panel.dataset.n = ''; }); };
  toggle('quest', draw);
};
ui.map = function () {
  const draw = () => { const S = G.S, cur = S.int ? S.ret.area : S.area;
    show('<h2>Mapa do Mundo</h2><p>Siga a trilha para a direita. 🟡 você está aqui · 🔒 chefe bloqueia o caminho</p><div style="display:flex;flex-wrap:wrap;gap:6px">' + G.AREAS.map((a, i) => { const v = S.visited[a.id], isC = a.id === cur, g = a.gate && !S.flags[a.gate]; return '<div class="card' + (isC ? ' sel' : '') + '" style="width:150px;opacity:' + (v ? 1 : .45) + '"><small>' + (i + 1) + '.</small> <b>' + (v ? a.n : '???') + '</b><br><small>' + (isC ? '🟡 aqui ' : '') + (g ? (v ? '🔒' : '') : (v ? '✔' : '')) + (a.boss ? ' ☠ chefe' : '') + '</small></div>'; }).join('→') + '</div><br><button id="bk">Fechar</button>'); panel.dataset.n = 'map'; on('bk', () => { close(); panel.dataset.n = ''; }); };
  toggle('map', draw);
};
ui.shop = function (key, who) {
  const draw = () => { const S = G.S, I = G.ITEMS; let list = (G.SHOPS[key] || []).map(id => id === 'stew2' ? 'stew' : id);
    const price = id => I[id].price || 20, buy = list.map(id => '<div class="card"><b>' + G.ico(id) + ' ' + I[id].n + '</b><br><small>' + I[id].d + '</small><br>' + price(id) + '' + G.COIN + ' <button data-b="' + id + '" class="' + (S.coins < price(id) ? 'dis' : '') + '">Comprar</button></div>').join('');
    const sell = Object.keys(S.inv).filter(id => I[id].t !== 'quest' && price(id) > 0).map(id => '<div class="card"><b>' + G.ico(id) + ' ' + I[id].n + '</b> ×' + S.inv[id] + '<br>' + Math.floor(price(id) * .4) + '' + G.COIN + ' <button data-s="' + id + '">Vender</button></div>').join('');
    show('<h2>' + who + ' · ' + G.COIN + ' ' + S.coins + '</h2><h3>Comprar</h3><div class="grid">' + buy + '</div><h3>Vender</h3><div class="grid">' + (sell || '<p>Nada para vender.</p>') + '</div><br><button id="bk">Sair</button>'); panel.dataset.n = 'shop';
    panel.querySelectorAll('[data-b]').forEach(b => b.onclick = () => { const id = b.dataset.b; if (S.coins < price(id)) { A.sfx('no'); return; } S.coins -= price(id); G.give(id, 1, true); A.sfx('coin'); draw(); });
    panel.querySelectorAll('[data-s]').forEach(b => b.onclick = () => { const id = b.dataset.s; if (['sword_wood', 'tunic'].includes(id) && S.inv[id] <= 1 || S.eq.weapon === id && S.inv[id] <= 1 || S.eq.armor === id && S.inv[id] <= 1 || S.eq.amulet === id && S.inv[id] <= 1) { G.toast('Desequipe antes de vender.'); return; } S.coins += Math.floor(price(id) * .4); G.take(id, 1); A.sfx('coin'); draw(); });
    on('bk', () => { close(); panel.dataset.n = ''; }); };
  draw();
};
ui.death = function () {
  show('<div class="menu"><h1 style="color:#ff6b5e">Você caiu…</h1><p>Tobi acorda com dores, mas Breu está ao seu lado. (Perde 10% das moedas)</p><button class="mbtn" id="d-r">Levantar e tentar de novo</button><button class="mbtn" id="d-m">Menu principal</button></div>'); panel.dataset.n = 'dead';
  on('d-r', () => { close(); panel.dataset.n = ''; G.respawn(); }); on('d-m', () => { close(); G.mode('menu'); ui.mainMenu(); });
};
ui.ending = function () {
  G.S.flags.ended = true; G.saveGame(); $('hud').classList.add('hidden'); $('touch').classList.add('hidden');
  playCine(G.OUTRO, () => { A.music('victory'); show('<h2>Fim da Campanha</h2><div class="credits">' + esc(G.CREDITS) + '\n\nNível final: ' + G.S.lvl + ' · Missões: ' + G.QUESTS.filter(q => G.S.quests[q.id] && G.S.quests[q.id].st === 'done').length + '/' + G.QUESTS.length + '\nInimigos derrotados: ' + G.S.kills + '</div><button id="bk">Continuar explorando</button><button id="bm">Menu principal</button>'); panel.dataset.n = 'end';
    on('bk', () => { close(); panel.dataset.n = ''; G.mode('play'); $('hud').classList.remove('hidden'); applyTouch(); }); on('bm', () => { close(); G.mode('menu'); ui.mainMenu(); }); });
};

/* ---------- botões do HUD ---------- */
on('b-pause', () => G.press('pause')); on('b-inv', () => G.press('inv')); on('b-map', () => G.press('map')); on('b-quest', () => G.press('quest'));

/* ---------- editar posição dos botões ---------- */
ui.editHud = function (done) {
  const s = G.settings, t = $('touch'); G.editHUD = true; panel.classList.add('hidden'); t.classList.remove('hidden'); t.classList.add('edit'); $('hud').classList.remove('hidden');
  const bar = document.createElement('div'); bar.id = 'editbar'; bar.innerHTML = 'Arraste o joystick e os botões para onde quiser<br><button id="e-ok">Concluir</button><button id="e-rs">Restaurar</button>'; document.body.appendChild(bar);
  const drag = (el, kx, ky) => { let sx, sy, ox, oy, on = false;
    el.onpointerdown = e => { on = true; sx = e.clientX; sy = e.clientY; ox = s[kx]; oy = s[ky]; el.setPointerCapture(e.pointerId); e.preventDefault(); };
    el.onpointermove = e => { if (!on) return; s[kx] = ox + e.clientX - sx; s[ky] = oy + e.clientY - sy; G.applyHud(); };
    el.onpointerup = el.onpointercancel = () => { on = false; G.saveSettings(); }; };
  drag($('joy'), 'jx', 'jy'); drag($('tbtns'), 'bx', 'by');
  $('e-rs').onclick = () => { s.jx = s.jy = s.bx = s.by = 0; G.applyHud(); G.saveSettings(); };
  $('e-ok').onclick = () => { G.editHUD = false; bar.remove(); t.classList.remove('edit'); $('joy').onpointerdown = $('tbtns').onpointerdown = null; panel.classList.remove('hidden'); if (G.mode() !== 'play') { t.classList.add('hidden'); } if (G.mode() === 'menu') $('hud').classList.add('hidden'); done(); };
};
/* ---------- toque ---------- */
(function touch() {
  const joy = $('joy'), k = $('joyk'); let id = null, cx = 0, cy = 0, R = 60;
  const mv = e => { const t = [...e.changedTouches].find(t => t.identifier === id) || (e.clientX !== undefined ? e : null); if (!t) return; let dx = t.clientX - cx, dy = t.clientY - cy; R = joy.offsetWidth / 2; const l = Math.hypot(dx, dy), m = Math.min(1, l / R); if (l > 0) { dx /= l; dy /= l; }
    G.IN.tx = dx * m; G.IN.ty = dy * m; G.IN.joy = m > .9; k.style.transform = 'translate(' + dx * m * R * .6 + 'px,' + dy * m * R * .6 + 'px)'; e.preventDefault(); };
  joy.addEventListener('touchstart', e => { if (G.editHUD) return; A.init(); const t = e.changedTouches[0]; id = t.identifier; const r = joy.getBoundingClientRect(); cx = r.left + r.width / 2; cy = r.top + r.height / 2; mv(e); }, { passive: false });
  joy.addEventListener('touchmove', mv, { passive: false });
  const end = e => { G.IN.tx = G.IN.ty = 0; G.IN.joy = false; k.style.transform = ''; id = null; }; joy.addEventListener('touchend', end); joy.addEventListener('touchcancel', end);
  const btn = (i, a, hold) => { const e = $(i); const d = ev => { if (G.editHUD) return; A.init(); if (hold) G.hold(a, true); else G.press(a); ev.preventDefault(); }, u = ev => { if (hold) G.hold(a, false); ev.preventDefault(); };
    e.addEventListener('touchstart', d, { passive: false }); e.addEventListener('touchend', u, { passive: false }); e.addEventListener('mousedown', d); e.addEventListener('mouseup', u); };
  btn('t-atk', 'atk'); btn('t-dodge', 'dodge'); btn('t-jump', 'jump'); btn('t-def', 'def', true); btn('t-int', 'int');
  $('t-sk').onclick = () => $('skring').classList.toggle('hidden');
  $('skring').querySelectorAll('[data-sk]').forEach(b => { const f = ev => { G.press('sk' + b.dataset.sk); ev.preventDefault(); }; b.addEventListener('touchstart', f, { passive: false }); b.addEventListener('click', f); });
})();
addEventListener('click', () => A.init(), { once: true });
const _m = G.mode; const _s = G.start; G.start = function (f) { _s(f); applyTouch(); };
G.applyHud(); window.addEventListener('load', () => G.boot());
})();
