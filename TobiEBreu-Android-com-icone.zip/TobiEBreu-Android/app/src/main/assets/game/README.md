# Tobi e Breu — A Aventura do Gnomo
Abra index.html (PC: WASD/setas, Espaço, E; celular: joystick e botões).
Configurações → transparência do HUD, transparência/tamanho dos botões, "Mover botões na tela", gato pixel-art on/off.
Créditos de arte: ver G.CREDITS (Kenney CC0, Ravenmore, folhas enviadas pelo autor — licenças a confirmar).
Sem textura enviada = removido (tochas, água, camas, estantes, balcão, forja, trono, fachadas de casa).
